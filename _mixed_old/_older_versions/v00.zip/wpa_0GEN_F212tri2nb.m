function nb = wpa_0GEN_F212tri2nb(tri)
% % % 14/05/14 rewritten by wp
% % %		no nodes input needed

	%% initialize
	src = sort(unique(tri(:)));
	ns = length(src);
	nb = cell(ns, 1);
	
	%% search
	parfor k = 1 : ns
		id3 = ismember(tri, src(k));
		id1 = any(id3, 2);
		tmp = tri(id1, :);
		nb{k} = unique(tmp(:));
	end
	
end %end of function

