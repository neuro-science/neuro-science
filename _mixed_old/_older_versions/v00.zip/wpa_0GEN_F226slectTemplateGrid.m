function [src, tp, kpID, nGrids] = wpa_0GEN_F226slectTemplateGrid (pnt, tri, rjID)


	%% 1. prepare parameters
	
	% % % check inputs sources
	if nargin < 2
		erorr('At least you need to tell me the pntations and triangluation of the sources!');
	end
	% % % check the rejected ids
	if nargin < 3
		fprintf('no reject IDs found, I will use defaults!\n');
		rjID = [341, 349, 358 : 367, 374 : 382, 387 : 400, 404 : 482];
	end
	
	% % % size of original data
	nInGrids = length(pnt);

	% % % get the results
	kpID = 1 : nInGrids;
	kpID(rjID) = [];
	src = pnt(kpID, :);
	nGrids = length(src);	%number of grids used
	
	% % % face update to new indices	
	ct = 0;	%a counter
	for k = 1 : length(tri)
		tmp = find(ismember(kpID, tri(k, :)));	% check existence
		if length(tmp) > 1
			ct = ct + 1;
			srf{ct} = tmp;	% update now
		end
	end
	nPatch = ct; %number of surfaces
	clear ct tmp;
	
	% % % topological relation definition
	tp = cell(nGrids, 1);
	for k = 1 : nGrids
		tmp = [];
		for t = 1 : nPatch
			if ismember(k, srf{t})
				tmp = [tmp, srf{t}];
			end
		end
		tp{k} = unique(tmp);
	end
	clear tmp k t;
	
end % end of function