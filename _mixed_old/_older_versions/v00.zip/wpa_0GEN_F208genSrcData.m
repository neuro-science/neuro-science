function src = wpa_0GEN_F208genSrcData (A, data)
% % % 	A : spatial filter (nChs, nGrids, nFreqs)
% % %		data : tf data {time, freq}(chan, trial, taper)
% % %				or tf(chan, trial, time, freq)
% % %		src : source data {time, freq}(grid, trial, taper)
% % %				or src(grid, trial, time, freq)

	[nChs2, nGrids, nFs2] = size(A);
	if iscell(data)
		src = cell(size(data));
		[nTs, nFs] = size(data);
		[nChs, nTrls, tmp] = size(data{1, 1});
		if nChs2 ~= nChs 
			error('mismatch in channel numbers!');
		elseif nFs == nFs2 %filter per frequency
			for iq = 1 : nFs
				tmpA = A(:, :, iq)';
				for it = 1 : nTs
					nTapers = size(data{it, iq}, 3);
					tmpD = reshape(data{it, iq}, [nChs, nTrls * nTapers]);
					src{it, iq} = reshape(tmpA * tmpD, [nGrids, nTrls, nTapers]); 
				end
			end
		elseif nFs2 == 1 %e.g. eloreta
			for iq = 1 : nFs
				for it = 1 : nTs
					nTapers = size(data{it, iq}, 3);
					tmpD = reshape(data{it, iq}, [nChs, nTrls * nTapers]);
					src{it, iq} = reshape(A' * tmpD, [nGrids, nTrls, nTapers]); 
				end
			end
		else
			error('mismatch in frequency numbers!');
		end %end of check in cell mode
	else
		[nChs, nTrls, nTs, nFs] = size(data);
		if nChs2 ~= nChs 
			error('mismatch in channel numbers!');
		elseif nFs == nFs2 %filter per frequency
			data = reshape(data, [nChs, nTrls * nTs, nFs]);
			src = zeros([nGrids, nTrls * nTs, nFs]);
			for iq = 1 : nFs
				tmpA = A(:, :, iq)';
				src(:, :, iq) = tmpA * data(:, :, iq);
			end
			src = reshape(src, [nGrids, nTrls, nTs, nFs]);
		elseif nFs2 == 1 %e.g. eloreta
			data = reshape(data, [nChs, nTrls * nTs * nFs]);
			src = reshape(A' * data, [nGrids, nTrls, nTs, nFs]);
		end %end of check in array mode	
	end % end of mode check
	
end % end of function