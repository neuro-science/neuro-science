function p = wpa_0GEN_F230SrcOnSurface(vc, tri, cv, src, ax, varargin)
% % % modified 12/05/14 by wp: new thresholds etc.
% % % rewrote  09/05/14 by wp: faces updated as in freesurfer_read_surf suggested

	%% prepare
	% % % default parameters for viewing
 	p.figPosSize = [900 100 900 900]; %position and size
	p.figColor = [1 1 1]; %background of figure
	p.axPosSize = [0 0 1 1];
	p.axLimSetFlag = 1; %axis limit need to be set
	p.axLim = [-100 100];
	p.axColor = [1 1 1]; %background of axis
	p.markerSize = 200;	%size of sources
	p.srcColor = [1 0 0];
	p.crxColor = cv;
	p.baseColorScale = 0.5;
	p.faceAlpha = 1;
	p.gaussFilterThresh = 20;
	p.viewDir = [0, -1, .7];
	p.dotExtRatio = 0;
	p.txtExtRatio = 0;
   p.colorThresh = 0.2;
	p.colorStyle = 'jet';
	p.colorScale = [];
	p.numIter = 1;
	p.maxSrcNum = 10000;	% assumption of maximum sources
	
	% % % input parameter overwrite defaults
	nVarArgIn = length(varargin);
	kCounter = 1; %arg in counter
	nUnknownPara = 0;	%number of unkown input, display only
	while kCounter < nVarArgIn
		switch lower(varargin{kCounter})
			case 'figpossize'
				p.figPosSize = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'axpossize'
				p.axPosSize = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'axlim'
				p.axLim = varargin{kCounter + 1};
				p.axLimSetFlag = 1;
				kCounter = kCounter + 1;
			case 'axcolor'
				p.axColor = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'markersize'
				p.markerSize = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'facealpha'
				p.faceAlpha = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'viewdir'
				p.viewDir = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'cscale'
				p.baseColorScale = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'cmax'
				p.maxSrcColor = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'dr'
				p.dotExtRatio = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'tid'
				p.txtSubscript = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'tr'
				p.txtExtRatio = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'gth'
				p.gaussFilterThresh = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'cth'
				p.colorThresh = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'cf'
				p.cfilter = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'cs'
				p.colorScale = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'cy'
				p.colorStyle = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'si'
				p.srcID = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'ni'
				p.numIter = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			case 'cvm'
				p.cvm = varargin{kCounter + 1};
				kCounter = kCounter + 1;
			otherwise
				nUnknownPara = nUnknownPara + 1;
				fprintf('\nUnknown parameter #%d: " %s " ...\n', varargin{kCounter});
		end
		kCounter = kCounter + 1;
	end % readin end
	
	
	% % % para set from fixed input
	switch size(src, 2) 
		case 3
% 			if size(src, 1) ~= size(vc, 1) %not color all vertices
				fprintf('Only location provided, uniform color [default: red] will be used.\n');
				p.srcPlot = 1;
				p.srcLocations = src;
% 			else
% 				fprintf('all color provided, show cortices.\n');
% 				p.srcPlot = 0;
% 				if max(src(:, 1)) > 1.1
% 					p.crxColor = src ./ 255;
% 				else
% 					p.crxColor = src;
% 				end
% 			end
		case 4
			fprintf('Both location and strength provided, color illustrate strength.\n');
			p.srcPlot = 0;
			if isfield(p, 'cfilter') && ~isempty(p.cfilter)
				vout = bsxfun(@rdivide, p.cfilter * src(:, 4), sum(p.cfilter, 2));
			elseif isfield(p, 'srcID') && ~isempty(p.srcID)
				vout = wpa_0GEN_F214smudge(src(:, 4), tri, p.srcID, p.numIter);
			elseif isfield(p, 'cvm') && ~isempty(p.cvm)
				vout = wpa_0GEN_F239TopoFilterGauss(src(:, 4), p.gaussFilterThresh, p.cvm);
			else
				vout = wpa_0GEN_F231SpatFilterGauss(vc, src(:, 1:3), p.gaussFilterThresh, src(:, 4));
			end
			[cTmp, sid] = wpa_0GEN_F232Value2MyColor(vout, p.colorThresh, p.colorScale, p.colorStyle);
			p.crxColor(sid, :) = cTmp(sid, :);
			clear cTmp sid;
		case 6
			fprintf('Both location and color provided, individual color will be used.\n');
			p.srcPlot = 1;
			p.srcLocations = src(:, 1:3);
			p.srcColor = src(:, 4:6);
		case 7
			fprintf('Both location and color provided, size as well, individual color will be used.\n');
			p.srcPlot = 1;
			p.srcLocations = src(:, 1:3);
			p.srcColor = src(:, 4:6);
			p.markerSize = src(:, 7);
		otherwise
			fprintf('I accept 3, 4, 6 or 7 columns input, now no source will be shown.\n');
			p.srcPlot = 0;
	end
	
	%% show images
	% % % prepare figue
	if isempty(ax)
		p.fid = figure('position', p.figPosSize, 'Color', p.figColor);
		% % % 	loop for 3 axes
		p.ax = axes('position', p.axPosSize, 'parent', p.fid, 'Color', p.axColor, ...
		 'XTick', [], 'XLim', p.axLim, 'YTick', [], 'YLim', p.axLim, 'ZTick', [], 'ZLim', p.axLim); %create axis
	else
		p.ax = ax;
	end
	hold on;
	p.mH = patch('faces', tri(:, [1 3 2]), 'vertices', vc, 'parent', p.ax, ...
		'facecolor', 'flat',  'edgecolor', 'none', 'facealpha', p.faceAlpha, ...
		 'FaceVertexCData', p.crxColor);
	hold on;
	if p.srcPlot
		p.dotLocations = p.srcLocations + bsxfun(@times, abs(p.srcLocations), p.dotExtRatio * p.viewDir);
		p.dH = scatter3(p.dotLocations(:, 1), p.dotLocations(:, 2), p.dotLocations(:, 3), ...
			p.markerSize, p.srcColor, '.', 'parent', p.ax);
		if isfield(p, 'txtSubscript')
			tmp = num2str(p.txtSubscript');
			p.txtLocations = p.srcLocations + bsxfun(@times, abs(p.srcLocations), p.txtExtRatio * p.viewDir);
			p.dT = text(p.txtLocations(:, 1), p.txtLocations(:, 2), p.txtLocations(:, 3), tmp);
		end
	end
	daspect(p.ax, [1 1 1]);
	axis tight;
	view(p.viewDir);
% 	p.l = light('parent', p.ax);
% 	set(p.l, 'position', p.viewDir, 'color', [.2 .2 .2]'); %.1 .1 .1 , 'Visible', 'off

end

