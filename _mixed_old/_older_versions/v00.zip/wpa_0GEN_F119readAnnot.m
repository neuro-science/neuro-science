function [ strName, label, clut ] = wpa_0GEN_F119readAnnot( lname, rname, nvs )
% % % 10/06/14 wp
% % % potential bug: when label==0, may be something wrong, although it
% % % should not be 0, but it happens - fixed

	% % % load data
% 	lname = '~/Documents/FreeSurfer/Rules_T00/label/lh.BA.annot';
	[v1, l1, c1] = read_annotation(lname);
% 	rname = '~/Documents/FreeSurfer/Rules_T00/label/rh.BA.annot';
	[v2, l2, c2] = read_annotation(rname);

	
	% % % 	consistency check
	d1 = length(v1) + length(v2);
	d2 = length(l1) + length(l2);
	if nargin < 3
		d3 = d2;
	else
		d3 = nvs;
	end
	
	% % % sort to one	
	if d1 ~= d2 || d2 ~= d3
		error('mismatch number of vertices!');
	else
		b1 = zeros(size(v1)) + nan;
		for iv = 1 : c1.numEntries
			strName{iv} = ['left_', c1.struct_names{iv}];
			b1(l1 == c1.table(iv, 5)) = iv;
		end
		b2 = zeros(size(v2));
		for iv = 1 : c2.numEntries
			strName{iv + c1.numEntries} = ['right_', c2.struct_names{iv}];
			b2(l2 == c2.table(iv, 5)) = iv + c1.numEntries;
		end
		b = [b1; b2];	
	end
	clut = [c1.table; c2.table];
	if ~isempty(find(isnan(b), 1))
		clut(end + 1, :) = [c1.numEntries + c2.numEntries + 1, 0, 0, 0, 0];
		strName{end + 1} = 'unknownunknown';
		b(isnan(b)) =	c1.numEntries + c2.numEntries + 1;
	end
	label = b;
end

