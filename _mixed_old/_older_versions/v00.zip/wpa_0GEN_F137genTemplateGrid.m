function d = wpa_0GEN_F137genTemplateGrid (tmpName, outName, maskName, nInGrids, depthIntoAC, acFlag)
% % % 22/06/14	renamed

	%% 1. prepare parameters
	
	% % % check inputs mri file
	if nargin < 1
		erorr('You need to tell me the locations of the template mri!');
	else
		d.inMRI = tmpName;
	end
	% % % check inputs mri file
	if nargin < 2
		error('Please specify an output name of the template mri for normalise !');
	else
		d.outMRI = outName;
	end
	% % % check the mask file 
	if nargin < 3
		fprintf('no mask file found, I will do segmentation\n');
		segFlag = 1;
	else
		segFlag = 0;
	end

	% % % check all grids to be generated
	if nargin < 4
		fprintf('No number of grids set, default 482 will be used!\n');
		d.nInGrids = 482;
	else
		d.nInGrids = nInGrids;
	end

	% % % depth into AC
	if nargin < 5
		fprintf('No depth to AC defined, use default (10 mm)\n');
		d.depthIntoAC = 10;
	else
		d.depthIntoAC = depthIntoAC;
	end
	
	% % % use geo centers or AC
	if nargin < 6
		fprintf('Take AC as center of brain.\n');
		d.acFlag = 1;
	else
		d.acFlag = acFlag;
	end
	
	%% 2. prepare the data
	% % % read data file - template anatomy mri
	tmp = ft_read_mri(tmpName);
	d.anatomy = tmp.anatomy;
	d.transform = tmp.transform;
	d.hdr = tmp.hdr;
	d.dim = tmp.dim;
	
	% % % template brain mask
	if segFlag
		cfg = [];
		cfg.output = 'brain';
		tmp = ft_volumesegment(cfg, d);	%segment mask
		d.brainMask = tmp.brain;
	else
		tmp = ft_read_mri(maskName);	 %read mask
		d.brainMask = logical(tmp.anatomy);
	end
	
	% % % get the indices
	idx0 = find(d.brainMask);   % find the points indices of brain
	[idx(:, 1), idx(:, 2), idx(:, 3)] = ind2sub(d.dim, idx0);	%is brain indices
	xs = min(idx);
	xe = max(idx);
	d.vox2nrm = [1 0 0 1 - xs(1);
		0 1 0 1 - xs(2);
		0 0 1 1 - xs(3);
		0 0 0 1];
	
	% % % Find the center and generate new transform matrix
	if d.acFlag 
		d.idxAC = warp_apply(inv(d.transform), [0 0 0]);	% 	by transform AC	
		d1.transform = d.transform / d.vox2nrm; %respect previous ras
	else
		d.idxAC = mean(idx);	% 	by center	
		d1.transform = [1 0 0 xs(1)+1-d.idxAC(1);	%new ras based on geo
			0 1 0 xs(2)+1-d.idxAC(2);
			0 0 1 xs(3)+1-d.idxAC(3);
			0 0 0 1];
	end

	% % % write new template for normalise
	data = d.anatomy .* d.brainMask;
	d1.anatomy = data(xs(1) : xe(1), xs(2) : xe(2), xs(3) : xe(3));
	d1.dim = size(d1.anatomy);
	d1.transform(1:3, 4) = d1.transform(1:3, 4) + (xs' - 1);
	ft_write_mri(d.outMRI, d1.anatomy, 'dataformat', 'nifti', 'transform', d1.transform);
	clear d1 xs xe data;
	
	%% 3. prepare the points
	% % % Go x mm inner toward center for the mask
	didx = bsxfun(@minus, idx, d.idxAC);    % difference between these coodinates and AC 
	dt = sqrt(sum(didx.^2, 2)); % distance in mm
	dt2 = dt - d.depthIntoAC;  % distance minus d.depthIntoAC
	dt2(dt2<0) = 0; % remove negative distace
	didx2 = bsxfun(@times, didx, dt2./dt);  % by this move the dots inner-wards
	idx2 = round(bsxfun(@plus, didx2, d.idxAC));    %transform to integer
	id = sub2ind(d.dim, idx2(:, 1), idx2(:, 2), idx2(:, 3));    %transform to indices again
	id = unique(id);    % remove dulplicates
	id(isnan(id)) = []; % remove meaningless ones //infact only ac
	tmp = false(d.dim); 	%new blank matrix
	tmp(id) = 1;   %new mask
	d.mask = volumefillholes(tmp);    % fill holes to generate new mask
	clear idx0 idx didx dt dt2 didx2 idx2 id tmp idx;

	% % % point on surface	
	[d.pnt, d.tri] = triangulate_seg(d.mask, d.nInGrids, d.idxAC);	%grid points as indices
	
	%% 4. triangulations for display
	fvc = isosurface(d.mask, d.anatomy);  % get the triangluate faces and vertices
	d.vc = fvc.vertices(:, [2 1 3]);		%resort the xyz dimension shifted by isosurface
	d.fc = fvc.faces;	%faces define
	d.cv = fvc.facevertexcdata * [1 1 1] / 200;	%vertices color []
	clear fvc;
	
end % end of function