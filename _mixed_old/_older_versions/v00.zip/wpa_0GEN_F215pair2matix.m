function arrayInMatrix = wpa_0GEN_F215pair2matix (arrayInPairs, dim, diagValue)
% % % 13/05/14 rewrote by wp for more dimensions allowed

	%% check headers
	if nargin < 3
		diagValue = 0;
	end
	
	if nargin < 2
		dim = -1;
	end
	
	sz = size(arrayInPairs);	%expect last dimension is the pair dimension

	%% do reshape for certain dimension
	if dim < 0 % last dimension
		id = sz(1 : end - 1);
		nPairs = sz(end);
		tmpData1 = reshape(arrayInPairs, [prod(id), nPairs]);
		nUnits = nPair2nUnit(nPairs);
		if abs(round(nUnits) - nUnits) > 1/10000	%not an integer
			error('The number of location pairs seems wierd, please have a double check!');
		end
		[p, nPairs] = unit2pair(nUnits);

		tmpData2 = zeros([prod(id), nUnits, nUnits]) + diagValue;
		for iPair = 1 : nPairs
			tmpData2(:, p(iPair, 2), p(iPair, 1)) = tmpData1(:, iPair);
			tmpData2(:, p(iPair, 1), p(iPair, 2)) = tmpData1(:, iPair);
		end
		arrayInMatrix = reshape(tmpData2, [id, nUnits, nUnits]);
	elseif dim == 1
		nPairs = sz(1);
		id = sz(2 : end);
		tmpData1 = reshape(arrayInPairs, [nPairs, prod(id)]);
		nUnits = nPair2nUnit(nPairs);
		if abs(round(nUnits) - nUnits) > 1/10000	%not an integer
			error('The number of location pairs seems wierd, please have a double check!');
		end
		[p, nPairs] = unit2pair(nUnits);

		tmpData2 = zeros([nUnits, nUnits, prod(id)]) + diagValue;
		for iPair = 1 : nPairs
			tmpData2(p(iPair, 2), p(iPair, 1), :) = tmpData1(iPair, :);
			tmpData2(p(iPair, 1), p(iPair, 2), :) = tmpData1(iPair, :);
		end
		arrayInMatrix = reshape(tmpData2, [nUnits, nUnits, id]);
	end
	clear tmpData1 tmpData2;
end


function y = nPair2nUnit(x)

	y = sqrt(x * 2 + .25) + .5;

end

function [pairs, nPairs] = unit2pair (nUnits)

	nPairs = nUnits * (nUnits - 1) / 2;
	pairs = zeros(nPairs, 2);
	ct = 0;
	for ch1 = 1 : nUnits - 1
		idx = ct + 1 : ct + nUnits - ch1;
		ct = ct + nUnits - ch1;
		pairs(idx, 1) = ch1 + 1 : nUnits ;
		pairs(idx, 2) = ch1;
	end

end