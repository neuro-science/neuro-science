function p = wpa_0GEN_F202plot2D_MRI(mri, dm, sm, dots, dd, tol, para)
% % % inputs: 
% % %		mri(3d array of data); 
% % %		dm(the dimension of selection for mri);
% % %		sm(selected point in mri);
% % %		dots(Nx3 dot locations); 
% % %		dd(the dimension of selection for dots);
% % %		sd(selected point in dots);

	%% plot the image
	% % % get the slice
	sz = size(mri);
	switch dm
		case 1
			im = mri(sm, :, :);
		case 2
			im = mri(:, sm, :);
		case 3
			im = mri(:, :, sm);
		otherwise
			error('data is 3D!');
	end
	sz(dm) = [];
	
	% % % proper contrast	
	switch class(im)
		case {'int8', 'int16', 'int32', 'int64', 'uint8', 'uint16', 'uint32', 'uint64'}
			im = double(im) ./ double(intmax(class(im)));
		otherwise
			tmp = max(abs(im(:)));
			im = im ./ (2.^nextpow2(tmp) - 1);
	end

	% % % get 3 layers color	
	im = repmat(squeeze(im), [1 1 3]);
	sz = size(im);

	% % % show it
	p = gca;
	image(1 : sz(2), 1 : sz(1), im, 'parent', p);
	set(p, 'ydir', 'normal', 'xlim', [1 sz(2)], 'ylim', [1 sz(1)], 'DataAspectRatio', [255 255 1]);
	if nargin > 6
		markersize = para.markersize;
	else
		markersize = 5;
	end
	if isfield(para, 'forceAxisSize');
		set(p, 'xlim', [1 para.forceAxisSize(1)], 'ylim', [1 para.forceAxisSize(2)]);
	end
	%% plot the dots
	if nargin > 3 && ~isempty(dots)
		% % % find dots to show	
		idx = abs(dots(:, dd) - sm) < tol;
		tmp = 1 : 3;
		tmp(dd) = [];
		xy = dots(idx, tmp);

		% % %	plot dots
		hold on;
		plot(xy(:, 2), xy(:, 1), 'r.', 'markersize', markersize, 'parent', p);
	end
end

