function out = wpa_0GEN_F228Normal0_1(in, range)

% % % 8/5/2014
	if nargin < 2
		M = max(in(:));
		m = min(in(:));
	else
		M = range(2);
		m = range(1);
	end
	out = (in - m) ./ (M - m);



end %end of function