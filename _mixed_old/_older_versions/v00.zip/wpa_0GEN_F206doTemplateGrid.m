function d = wpa_0GEN_F206doTemplateGrid (tmpName, maskName, nInGrids, depthIntoAC, acFlag, rjID)
% % % 22/06/14	saved again

	%% 1. prepare data
	
	% % % check inputs mri file
	if nargin < 1
		erorr('at least you need to tell me the locations of the template mri!');
	end
	% % % check the mask file 
	if nargin < 2
		fprintf('no mask file found, I will do segmentation\n');
		segFlag = 1;
	else
		segFlag = 0;
	end

	% % % check all grids to be generated
	if nargin < 3
		fprintf('No number of grids set, default 482 will be used!\n');
		nInGrids = 482;
	end

	% % % depth into AC
	if nargin < 4
		fprintf('No depth to AC defined, use default (10 mm)\n');
		depthIntoAC = 10;
	end
	
	% % % reject grids ID
	if nargin < 5
		fprintf('Take AC as center of brain.\n');
		acFlag = 1;
	end
	
	% % % reject grids ID
	if nargin < 6
		fprintf('No reject ID defined, I will use default.\n');
		rjID = [341, 349, 358 : 367, 374 : 382, 387 : 400, 404 : 482];
	end
	
	% % % read data file - template anatomy mri
	d = ft_read_mri(tmpName);

	% % % template brain mask
	if segFlag
		cfg = [];
		cfg.output = 'brain';
		m = ft_volumesegment(cfg, d);	%segment mask
		brainMask = m.brain;
	else
		m = ft_read_mri(maskName);	 %read mask
		brainMask = m.anatomy;
	end
	% % % Find the center
	if acFlag 
		d.idxAC = warp_apply(inv(d.transform), [0 0 0]);	% 	by transform AC	
	else
		idx0 = find(brainMask);   % find the points indices of brain
		[idx(:, 1), idx(:, 2), idx(:, 3)] = ind2sub(d.dim, idx0);	%is brain indices
		d.idxAC = mean(idx);	% 	by center	
	end
	
	%% 2. prepare the inner mask and anatomy
	% % % Go x mm inner toward center for the mask
	didx = bsxfun(@minus, idx, d.idxAC);    % difference between these coodinates and AC 
	dt = sqrt(sum(didx.^2, 2)); % distance in mm
	dt2 = dt - depthIntoAC;  % distance minus depthIntoAC
	dt2(dt2<0) = 0; % remove negative distace
	didx2 = bsxfun(@times, didx, dt2./dt);  % by this move the dots inner-wards
	idx2 = round(bsxfun(@plus, didx2, d.idxAC));    %transform to integer
	id = sub2ind(d.dim, idx2(:, 1), idx2(:, 2), idx2(:, 3));    %transform to indices again
	id = unique(id);    % remove dulplicates
	id(isnan(id)) = []; % remove meaningless ones //infact only ac
	tmp = false(d.dim); 	%new blank matrix
	tmp(id) = 1;   %new mask
	d.mask = volumefillholes(tmp);    % fill holes to generate new mask
	clear idx0 idx didx dt dt2 didx2 idx2 id tmp idx;

	% % % locations for display
	fvc = isosurface(d.mask, d.anatomy);  % get the triangluate faces and vertices
	d.vc = fvc.vertices(:, [2 1 3]);		%resort the xyz dimension shifted by isosurface
	d.fc = fvc.faces;	%faces define
	d.cv = fvc.facevertexcdata * [1 1 1] / 200;	%vertices color []
	clear fvc;

	%% 3. template grid point on surface
	% % % point on surface	
	[pnt, tri] = triangulate_seg(d.mask, nInGrids, d.idxAC);	%grid points as indices
	
% 	% % % plot and select	
% 	p = wpa_0GEN_F14SrcOnSurface (d.vc, d.fc, d.cv, pnt, [], ...
% 		'gTH', 2, 'markersize', 300, 'dr', 0.07, 'tr', 0.1, ...
% 		'viewdir', [0, 0, -1], 'tid', 1 : nInGrids);
% 	srcColor = [ 0 0 1];
% 	p.dH = scatter3(p.dotLocations(rjID, 1), p.dotLocations(rjID, 2), p.dotLocations(rjID, 3), ...
% 		 p.markerSize, srcColor, '.');	%plot the removal ones

	% % % get the results
	d.kpID = 1 : nInGrids;
	d.kpID(rjID) = [];
	d.allPoints = pnt;
	d.idxGrid = pnt(d.kpID, :);
	d.grdRAS = warp_apply(d.transform, d.idxGrid);
	d.nGrids = length(d.grdRAS);	%number of grids used
	
	% % % face update to new indices	
	ct = 0;	%a counter
	for k = 1 : length(tri)
		tmp = find(ismember(d.kpID, tri(k, :)));	% check existence
		if length(tmp) > 1
			ct = ct + 1;
			srf{ct} = tmp;	% update now
		end
	end
	d.nPatch = ct; %number of surfaces
	clear ct tmp;
	
	% % % topological relation definition
	d.tp = cell(d.nGrids, 1);
	for k = 1 : d.nGrids
		tmp = [];
		for t = 1 : d.nPatch
			if ismember(k, srf{t})
				tmp = [tmp, srf{t}];
			end
		end
		d.tp{k} = unique(tmp);
	end
	clear tmp k t;
	
end % end of function