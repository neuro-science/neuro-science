function [t, d] = wpa_0GEN_F120sen2src2t(d,  A)
% % % written 20/06/2014
% % % updated 23/06/2014 for baseline comparison
	nvxs = size(A, 1);
	[nchs, npts, ntrs, ncps] = size(d);	%
	d = reshape(A * reshape(d, [nchs, npts * ntrs * ncps]), ...
		[nvxs, npts, ntrs, ncps]);	%sen2src
	m = mean(d, 3);
	s = std(d, 0, 3);
	if ncps == 2
		t = (m(:, :, :, 1) - m(:, :, :, 2)) ./ sqrt((s(:, :, :, 1) .^2 + s(:, :, :, 2) .^2 ) / ntrs);
	elseif ncps == 1
		t = sqrt(ntrs) * m ./ s;
	else
		t = [];
	end
end

