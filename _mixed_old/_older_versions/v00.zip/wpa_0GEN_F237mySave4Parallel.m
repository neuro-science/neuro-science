function [err, ME] = wpa_0GEN_F237mySave4Parallel( fname, v, vname )
	% % % 13/05/14 written by wp - save within parallel computation
	
	err = [];
	ME = [];
	if nargin < 3
		try
			save(fname, 'v', '-v7.3');
		catch ME
			err = ME.message;
		end
	else
		str = [vname, ' = v;'];
		eval(str);
		try
			save(fname, vname, '-v7.3');
		catch ME
			err = ME.message;
		end
	end % end of whether custom name switch
	clear v;
end % end of function

