function dOut = wpa_0GEN_F221readFromFieldtrip (data)

	%% 1. get sensor information
	dOut.nChans = length(data.label);
	sChanID = 1 : dOut.nChans;
	dOut.chanInfo = [data.grad.coilpos(sChanID, :), data.grad.coilori(sChanID, :)];
	dOut.refInfo = [data.grad.coilpos(sChanID + dOut.nChans + min(sChanID) - 1, :), ...
		-data.grad.coilori(sChanID + dOut.nChans + min(sChanID) - 1, :)];	
end %
