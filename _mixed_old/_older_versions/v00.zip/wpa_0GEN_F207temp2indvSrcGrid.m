function a = wpa_0GEN_F207temp2indvSrcGrid (a, locSensors, locReferences)
% % % 07/05/2014 Peng Wang	

	%% 0. para set
	if ~isfield(a, 'surfFitPara')
		a.surfFitPara = 10;
	end
	if ~isfield(a, 'megFitPara')
		a.megFitPara = 10;
	end
		
	%% 3. check the volume conductor
	cfg = [];
	vol = ft_prepare_singleshell(cfg, a);
	a.bnd = vol.bnd;
	clear vol;

	%% 4. volume conductor
	[a.vol6, a.vCenter, radius, coeffs] = pointsonsurface(a.bnd.pnt, a.bnd.pnt, a.surfFitPara); %get norm
	a.fp_indi = meg_ini(a.vol6, a.vCenter', a.megFitPara, locSensors, locReferences);  %single shell
	
	%% 5. Leadfield
	a.L = grid2L(a.src, a.fp_indi); %lead field	
end % end of function

