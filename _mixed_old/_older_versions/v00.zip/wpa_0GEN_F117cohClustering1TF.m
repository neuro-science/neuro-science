function [myClusters, sz, nc] = wpa_0GEN_F117cohClustering1TF (conArray, neighborDefinition, conThresh, spfThresh)

% xx_coherence_clustering will find clusters based on the 
% connection array, which defines cnnection strength between locations
% in various time and frequency. The algirthm came from the 2011 Neuron
% paper by Hipp, J.F. Engel, A.K. and Siegel, M.

% Use as
%   myClusters = xx_coherence_clustering (conArray, neighborDefinition, conThresh, spfThresh)
% 
% Input:
%		conArray					- a location x location array, defining the
%									connection strength between two locations at certain 
%									time and frequency
%		neighborDefinition	- a numGrid x 1 cell array, k-th element contains neigboring 
%									grids of grid k.
%		conThresh				- threshhold of connection strength, value in conArray 
%									above it will indicate a connection or else not. 
%		spfThresh				- spatial filter will be applied to remove spurious connection.
%		method               - method of clustering, can be 'node' or 'edge' 
% 
% 
% Output:
%		myClusters - a cell array, each element contains a cluster
% 
% 
% 
% Written by Peng Wang, Institute of Neurophysiology, UKE.
%
%   Modification History:
%   08/2013: First Formal Draft
%   10/2013: improved Draft to allow more strategies
%   05/2014: improved Draft for more compact sub function
%   05/2014: improved Draft for 1 Time-Frequency point

	
	%% preparision
	if nargin < 2
		error('At least two inputs needed: connection array, neigbor definition and two thresholds.');
	else
		if nargin < 3
			conThresh = 2.86;	% 
		end
		if nargin < 4
			spfThresh = 0.5;
		end
% 	elseif nargin < 5
% 		method = 'node';
	end
	
	%% thresholding to binary
	binArray = conArray > conThresh;
	
	%% spatial filtering
	binArray = topoFilter(binArray, neighborDefinition, spfThresh);
	
	%% find cluster
% 	switch lower(method)
% 		case 'node'
			[myClusters, nc] = doFindClusterByNodes(binArray);
% 		case 'edge'
% 			[myClusters, nc] = doFindClusterByEdges(binArray, neighborDefinition);
% 		otherwise
% 			error('Current supported methods are <node> and <edge> only!');
% 	end
	
	%% sort cluster
	if nc > 0
		tmp = zeros(nc, 1);
		nn = zeros(nc, 1);
		for k = 1 : nc
			tmp(k) = sum(conArray(myClusters{k}.id));
			myClusters{k}.sz = tmp(k);
			nn(k) = myClusters{k}.nn;
		end
		[sz, I] = sort(tmp, 'descend');
		myClusters = myClusters(I);
		J = find(nn > 10);
		clear I tmp;
	else
		sz = [];
		J = [];
	end
	nc = J;
end

%% subfunctions 1
function	outBinArray = topoFilter(binArray, neighborDefinition, spfThresh)
	% % % prepare para
	sz = size(binArray);	%expect(f, t, node, node)
	nNodes = length(neighborDefinition);
	if sz(1) ~=nNodes
		error('inconsistent grid number in connection and neighbor definition!');
	end
	
	% % % numbers of possible spatial neighbors	
	nNeighborsPossiblePerNode = zeros(nNodes, 1);
	for k = 1 : nNodes
		nNeighborsPossiblePerNode(k) = length(neighborDefinition{k}) - 1;	%spatial neighbor per node
	end
	nNeighborsPossiblePerEdge = bsxfun(@plus, nNeighborsPossiblePerNode, nNeighborsPossiblePerNode');

	% % % 	real connections
	nNeighborsPerEdge = topoCon(binArray, neighborDefinition);
	
	% % % 	connection after filter
	outBinArray = binArray & (nNeighborsPerEdge > spfThresh * nNeighborsPossiblePerEdge);

end

%% subfunctions 2
function [c, nc] = doFindClusterByNodes(con)

	sz =size(con);
	for ch1 = 1 : sz(1) - 1
		con(ch1, ch1 : sz(1)) = 0;
	end
	[x1, x2] = ind2sub(sz, find(con));
	nds = length(x1);
	fg = true(nds, 1);
	ids = [x1, x2];
	nc = 0;
	c = [];
	for ig = 1 : nds
		if fg(ig)
			cid = [];
			[cid, fg] = searchClusterLoopSparse(ids, ig, cid, fg);
			if ~isempty(cid)
				nc = nc + 1;
				c{nc}.ne = length(cid);
				c{nc}.ed = ids(cid, :);
				c{nc}.nd = unique(ids(cid, 1:2));
				c{nc}.nn = length(c{nc}.nd);
				c{nc}.id = sub2ind(sz, x1(cid), x2(cid));
			end
		end
	end
end

%% sub- subfunctions 1
function	nNeighborsTopoSpatial = topoCon(binArray, neighborDefinition)

	sz = size(binArray);	%expect(node, node)
	nNeighborsTopoSpatial = zeros(sz);
	
	for iNode = 1 : sz(1)
		idx = neighborDefinition{iNode};	%all neighbors
		idx(idx == iNode) = [];	%exclude itself
		nNeighborsTopoSpatial( :, iNode) = nNeighborsTopoSpatial(:, iNode) + sum(binArray( :, idx), 2);
		nNeighborsTopoSpatial( iNode, :) = nNeighborsTopoSpatial( iNode, :) + sum(binArray( idx, :), 1);
		nNeighborsTopoSpatial( iNode, iNode) = 0;	%auto connection is set as 0
	end
% 	nNeighborsTopoSpatial(nNeighborsTopoSpatial < 0) = 0;
end

%% sub- subfunctions 2
function [y, flag] = searchClusterLoopSparse(c2, x, y, flag)

	ng = length(x);
	x2 = [];
	for k = 1 : ng
		if flag(x(k))
			flag(x(k)) = 0;
			y = [y; x(k)];
			s1 = c2 == c2(x(k), 1);
			s2 = c2 == c2(x(k), 2);
			s = find(any(s1 | s2, 2));
			x2 = [x2; s];
		end
	end
	x2 = unique(x2);
	if ~isempty(x2)
		[y, flag] = searchClusterLoopSparse(c2, x2, y, flag);
	end
end
