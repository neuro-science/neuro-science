function mri = wpa_0GEN_F223temp2indvSrcGridLegacy (mri, srcLocs, locSensors, locReferences)

	%% 1. segmentation for brain and skull	
	cfg = [];
	cfg.output = {'brain'};
	seg = ft_volumesegment(cfg, mri);
	mri.seg = seg.brain;
	
	%% 2. get the volume surface
	cfg = [];
	vol = ft_prepare_singleshell(cfg, seg);
	mri.bnd = vol.bnd;
	
	%% 3. volume conductor
	[mri.vol6, mri.vCenter, radius, coeffs] = pointsonsurface(vol.bnd.pnt, vol.bnd.pnt, 10); %get norm
	mri.fp_indi = meg_ini(mri.vol6, mri.vCenter', 10, locSensors, locReferences);  %single shell
	
	%% 4. generate the forward model
	mri.srcLocs = srcLocs;
	mri.L = grid2L(mri.srcLocs, mri.fp_indi); %lead field
	
end % end of function

