% % % modified 4/11/2013 both end and 1st
function	[outBinArray, nNeighborsInTime, nNeighborsTopoSpatial] = ...
	wpa_0GEN_F127erfClusterSpatialFilterm(binArray, neighborDefinition, spfThresh)

	% % % prepare para
	[nNodes, nTimes] = size(binArray);	%expect(f, t, node)
	
	% % % numbers of possible spatial neighbors	
	nNeighborsPossiblePerNode = zeros(nNodes, 1);
	for k = 1 : nNodes
		nNeighborsPossiblePerNode(k) = length(neighborDefinition{k}) - 1;	%spatial neighbor per node
	end
	
	% % % numbers of possible time-frequency neighbors	
	nNeighborsPossiblePerTime = zeros(nTimes, 1) + 2;
	nNeighborsPossiblePerTime(1) = nNeighborsPossiblePerTime(1) - 1;
	nNeighborsPossiblePerTime(end) = nNeighborsPossiblePerTime(end) - 1;

	% % % real number of Neighbors	
	nNeighborsInTime = tfFilter(binArray);
	nNeighborsTopoSpatial = topoFilter(binArray, neighborDefinition);
	
	% % % sum together and apply filter	
	nNeighborsPossibleAll = bsxfun(@plus, nNeighborsPossiblePerNode, nNeighborsPossiblePerTime');
	outBinArray = binArray & ((nNeighborsInTime + nNeighborsTopoSpatial) > spfThresh * nNeighborsPossibleAll);
end

function nNeighborsInTime = tfFilter(binArray)
	[nNodes, nTimes] = size(binArray);	%
	tmpArray = zeros([nNodes nTimes 2]);
	% % % shift array to 	
	tmpArray(:, 2 : end, 1) = binArray(:, 1 : end - 1);
	tmpArray(:, 1 : end - 1, 2) = binArray(:, 2 : end);
	nNeighborsInTime = sum(tmpArray, 3);
end

function	nNeighborsTopoSpatial = topoFilter(binArray, neighborDefinition)

	[nNodes, nTimes] = size(binArray);	%
	nNeighborsTopoSpatial = zeros([nNodes, nTimes]);
	if nNodes ~= length(neighborDefinition)
		error('inconsistent grid number in connection and neighbor definition!');
	end
	
	for iNode = 1 : nNodes
		idx = neighborDefinition{iNode};	%all neighbors
		idx(idx == iNode) = [];	%exclude itself
		nNeighborsTopoSpatial(iNode, :) = nNeighborsTopoSpatial(iNode, :) + sum(binArray(idx, :), 1);
	end
end
