function nb = wpa_0GEN_F125tri2nb (vc, tri)
	
	% % % face update to new indices	
	nvs = size(vc, 1);
	ct = 0;	%a counter
	for k = 1 : size(tri, 1)
		tmp = find(ismember(vc, tri(k, :)));	% check existence
		if length(tmp) > 1
			ct = ct + 1;
			srf{ct} = tmp;	% update now
		end
	end
	nPatch = ct;
	clear ct tmp;
	
	% % % topological relation definition
	nb = cell(nvs, 1);
	for k = 1 : nvs
		tmp = [];
		for t = 1 : nPatch
			if ismember(k, srf{t})
				tmp = [tmp; srf{t}];
			end
		end
		nb{k} = unique(tmp);
	end
	clear tmp k t;
	
end