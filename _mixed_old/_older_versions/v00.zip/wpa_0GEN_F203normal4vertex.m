function [nrm, triNormal, triArea, triCenter] = wpa_0GEN_F203normal4vertex( vc, tri )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

	%% information get and set
	ntris = size(tri, 1);
	nvcs = size(vc, 1);
	triArea = zeros(1, ntris);
	nrm = zeros(nvcs, 3);
	
	%% compute triangle normals
	r1 = vc(tri(:, 1), :);
	r2 = vc(tri(:, 2), :);
	r3 = vc(tri(:, 3), :);
	triCenter = (r1 + r2 + r3) / 3.0;
	triNormal   = cross((r2 - r1), (r3 - r1));
	for k = 1 : ntris
		sz = sqrt(triNormal(k, :) * triNormal(k, :)');
		triArea(k) = sz / 2.0;
		if sz > 0.0
			triNormal(k, :) = triNormal(k, :) / sz;
		end
	end
	
	%% compute vertex normals
	for k = 1 : ntris
		nrm(tri(k, :), :) = nrm(tri(k, :), :) + kron(ones(3, 1), triNormal(k, :));
	end
	for k = 1:nvcs
		sz = sqrt(nrm(k, :) * nrm(k, :)');
		if sz > 0
			 nrm(k, :) = nrm(k, :) / sz;
		end
	end

end % end of function