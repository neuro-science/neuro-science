% % % updated 16/05/2013 - improve figure property
% % % updated 15/05/2013 - add central sensor bold
% % % topo plot done ?
function cfg = wpa_0GEN_F102corrPlot2D(data, M, cfg)

	%% 1. check header
	sz = size(data);
	if length(sz) ~= 2
		error('only 2-d data supported so far!');
	end
	
	if nargin < 2
		M = [];
	end
	
	if nargin < 3
		cfg = [];
	end
	
	if iscomplex(data)
		fprintf('complex data detected, absolute value will be displayed!');
		data = abs(data);
	end
	
	if isfield(cfg, 'x') && ~isempty(cfg.x);
		x = cfg.x;
	else
		x = 1 : sz(2);
	end
	
	if isfield(cfg, 'y') && ~isempty(cfg.y);
		y = cfg.y;
	else
		y = 1 : sz(1);
	end
	
	%% 2. color by data value
	d = wpa_0GEN_F232Value2MyColor(data(:), 0, M, 'j');
	data = reshape(d, [sz, 3]);
	clear d;
	
	%% 3. display
	cfg.ax = gca;
	h = image(x, y, data, 'parent', cfg.ax);
	set(cfg.ax, 'ydir', 'normal', 'DataAspectRatio', [255 255 1]);
end %end of function
	
% 	%% compute
% 	% % % set some parameters
% 	if ~isfield(cfg, 'exRange')
% 		cfg.exRange = 0.5;
% 	end
% 	if ~isfield(cfg, 'nPixels1D')
% 			cfg.nPixels1D = 1000;
% 	end
% 	if ~isfield(cfg, 'nPixels1D')
% 			cfg.nPixels1D = 1000;
% 	end
% 	if ~isfield(cfg, 'doPlot')
% 			cfg.doPlot = 1;
% 	end

% 	% % % prepare data
% 	if verLessThan('matlab', '8.1')
% 		F = TriScatteredInterp(cfg.posiChan, data);
% 	else
% 		F = scatteredInterpolant(cfg.posiChan, data);
% 	end
% 	tmp = linspace(-cfg.exRange, cfg.exRange, cfg.nPixels1D);
% 	[pX,pY] = meshgrid(tmp, tmp);
% 	pZ = F(pX, pY);
% 
% 	%% Plot
% 	if cfg.doPlot
% 		% % % figure handles
% 		if ~isfield(cfg, 'fid')
% 			cfg.fid = figure('position', [900 100 900 900], 'Color', [1 1 1]);
% 			cfg.aid = axes('position', [0.1 0.1 0.8 0.8]);
% 		elseif ~isfield(cfg, 'aid')
% 			cfg.aid = axes('position', [0.1 0.1 0.8 0.8]);
% 		end
% 		
% 		% % % color 
% 		cZ = wpa_0GEN_F106Value2MyColor(pZ(:), 0);
% 
% 		% % % Remove outsiders
% 		cZ = reshape(cZ, [cfg.nPixels1D * cfg.nPixels1D, 3]);
% 		outSiders = (sqrt(pX.^2 + pY.^2) > cfg.exRange);
% 		nanZ = isnan(cZ(:, 1)) | outSiders(:);
% 		cZ(nanZ, :) = 1;
% 		cZ = reshape(cZ, [cfg.nPixels1D, cfg.nPixels1D, 3]);
% 		
% 		% % % plot		
% 		h = image(pX(1, :), pY(:, 1), cZ, 'parent', cfg.aid);
% 
% 		% % % landmark electrodes on?
% 		if ~isfield(cfg, 'elecOn')
% 				cfg.elecOn = 0;
% 		elseif cfg.elecOn 
% 			if ~isfield(cfg, 'elecSize')
% 				cfg.elecSize = 10;
% 			end
% 			if isfield(cfg, 'spSensors')
% 				cfg.spFlag = 1;
% 				if ~isfield(cfg, 'elecSizeB')
% 					cfg.elecSizeB = 20;
% 				end
% 			end
% 		end
		
% 		% % % plot electrodes if needed
% 		if cfg.elecOn
% 			hold on;
% 			h2 = plot(cfg.posiChan(:, 1), cfg.posiChan(:, 2), '.k', 'markersize', cfg.elecSize);
% 			if cfg.spFlag
% 				h3 = plot(cfg.posiChan(cfg.spSensors, 1), cfg.posiChan(cfg.spSensors, 2), '.m', 'markersize', cfg.elecSizeB);
% 			end
% 		end
% 		axis(cfg.aid, [-cfg.exRange cfg.exRange -cfg.exRange cfg.exRange]);
% 		axis equal;
% 		axis off;
% 	else
% % 		h = get(cfg.aid, 'children');
% % 		set(h(end), 'CData', pZ);
% 	end
