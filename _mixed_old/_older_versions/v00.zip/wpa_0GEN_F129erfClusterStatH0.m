function H0 = wpa_0GEN_F129erfClusterStatH0(data, tp, th1, th2, nClustersPerTest, nTestPerCluster, fid)
% % % written 21/06/14
% % % updated 23/06/14 for output fid and input check

	%% check paras
	[nds, npts, tmp1, tmp2] = size(data);
	if tmp2 > 1
		ntrs = tmp1 * tmp2;
		data = reshape(data, [nds, npts, ntrs]);
	else
		if mod(tmp1, 2)
			data(:, :, end) = [];
			ntrs = tmp1 - 1;
		end
	end
	if nargin < 2
		error('data and connections shall be provided!\n');
	elseif nargin < 3
		th1 = 2.1; % p<0.05
	elseif nargin < 4
		th2 = 0.5; % 50% connection
	elseif nargin < 5
		nClustersPerTest = 3;
	elseif nargin < 6
		nTestPerCluster = 1000;
	elseif nargin < 7
		fid = 1;
	end
	
	%% initialize
	H0 = zeros(nClustersPerTest, nTestPerCluster);
	
	%% do in loop
	for ts = 1 : nTestPerCluster
		tic;

		% % % prepare data
		s = randperm(ntrs);
		d = reshape(data(:, :, s), [nds, npts, ntrs/2, 2]);
		m = mean(d, 3);
		s = std(d, 0, 3);
		t = abs(m(:, :, :, 1) - m(:, :, :, 2)) ./ sqrt(2 * (s(:, :, :, 1) .^2 + s(:, :, :, 2) .^2 ) / ntrs);

		% % % do cluster
		[tmp1, sz, tmp3] = wpa_0GEN_F126erfClustering (t, tp, th1, th2);
		
		% % % fill the results		
		szn = zeros(nClustersPerTest, 1);
		ssz = length(sz);
		if ssz >= nClustersPerTest
			szn(:, 1) = sz(1 : nClustersPerTest);
		elseif ssz > 0
			szn(1 : ssz, 1) = sz;
		end
		H0(:, ts) = szn;
		
		% % % echo message		
		fprintf(fid, 'Test #%03d done after %7.2f seconds.\n', ts, toc);
	end
	
end %end of function

