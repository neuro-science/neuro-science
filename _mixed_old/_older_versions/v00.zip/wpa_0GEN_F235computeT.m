function t = wpa_0GEN_F235computeT(data, dim)
% % % 12/05/14 written by wp
% % % 26/05/14	modified by wp:
% % %		use nan for the missing values

	if nargin < 2 %default last dim
		dim = length(size(data));
	end
	n = size(data, dim);
	m = nanmean(data, dim);
	s = nanstd(data, 0, dim);
	t = sqrt(n) * squeeze(m./s);
	
end