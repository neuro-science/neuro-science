function a = wpa_0GEN_F205MRI2Filter (mriName, tmpName, srcLocs, senLocs, refLocs, CC)
	

	%% 1. read the ctf mri data and get correct transform informatin
	a = ft_read_mri(mriName);
	a.transform = [1 0 0 -a.hdr.headOrigin_sagittal; ...
		0 -1 0 a.hdr.headOrigin_coronal; ...
		0 0 -1 a.hdr.headOrigin_axial; ...
		0 0 0 1];
	a.senLocs = senLocs;
	a.refLocs = refLocs;
	
	%% 2. segmentation for brain and skull	
	cfg = [];
	cfg.output = {'brain', 'skull'};
	seg = ft_volumesegment(cfg, a);
	
	%% 3. get the transformation matrix for normalization
	if isempty(tmpName)
		a.srcLocs = srcLocs;
	else
		cfg = [];
		cfg.template = tmpName;
		b = rmfield(a, {'brainCenterCTF', 'hdr', 'coordsys'});
		b.anatomy = b.anatomy(:, end:-1:1, end:-1:1);
		b.transform = [1 0 0 -a.hdr.headOrigin_sagittal; ...
			0 1 0 a.hdr.headOrigin_coronal - 257; ...
			0 0 1 a.hdr.headOrigin_axial - 257; ...
			0 0 0 1];
		nrm = ft_volumenormalise(cfg, b);
		a.srcLocs = warp_apply(a.transform \ b.transform * nrm.params.Affine, srcLocs);
	end
	a.nSrcs = size(a.srcLocs, 1);
	
% 	%% 4. check the results
% 	cfg = [];
% 	cfg.markersize = 15;
% 	for k = 30 : 10 : 220
% 		p = wpa_0GEN_F202plot2D_MRI (a.anatomy, 1, k, a.srcLocs, 1, 5, cfg);
% 		pause;
% 	end
	
	
	%% 5. volume conductor locations
	cfg = [];
	cfg.method = 'singleshell';
	seg1 = rmfield(seg, {'brain', 'skull'});
	seg1.brain = seg.skull;
	vol = ft_prepare_singleshell(cfg, seg1);
	a.volpnt = vol.bnd.pnt;
	
	%% 6. leadfield computation
	[cc, rr] = sphfit(a.volpnt);
	[ff, ee] = harmfit(a.volpnt, cc, 10);
	a.volpnt6 = mk_vcharm(a.volpnt, cc, ff);
	a.fp = meg_ini(a.volpnt6, cc', 10, a.senLoc, a.refLoc);  %single shell
	a.L = grid2L(a.srcLocs, a.fp);
	
	%% 7. spatial filter computation
	[a.nChs, a.nChs, a.nFilters] = size(CC);
	a.spF = zeros(a.nChs, a.nSrcs, a.nFilters);
	for it = 1 : a.nFilters
		[A, A1, rv] = wpa_0GEN_F301Beamforming_lcmv(CC(:, :, it),  a.L, 0.01);
		a.spF(:, :, it) = A1';
	end
	
end % end of function

