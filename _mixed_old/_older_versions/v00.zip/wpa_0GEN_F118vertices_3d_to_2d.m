function xy = wpa_0GEN_F118vertices_3d_to_2d(idx, l2d, i2d)
% function xy = wpa_0GEN_F118vertices_3d_to_2d(idx, l2d, i2d, tri, nr)
% % % 20/05/14 by wp
%   Detailed explanation goes here
% 	if nargin < 5
% 		nr = 10;
% 	end
	
	ind = find(idx);
	idx0 = find(i2d);
% 	nps = length(ind, 1);
	[xy, fg] = doFind2D(idx0, ind, l2d);
% 	while nr > 0 && any(fg)
% 		nd = ind(fg);
% 	end
% for k = 1 : nps;
% 	tmp = ismember(idx0, ind(k));
% 	if any(tmp)
% 		xy(k, :) = g.src.v2d(tmp, :);
% 	else
% 		fprintf('pixel %d is void!\n', k);
% 		xy(k, :) = nan;
% 	end
% end
% tmp = find(isnan(xy(:, 1)));
% nn = size(tmp, 1);
% px = ind(tmp);
% xy2 = zeros(nn, 2);
% for k = 1 : nn
% 	tmp = any(ismember(g.src.fc, px(k)), 2);
% 	tmp1 = unique(g.src.fc(tmp, :));
% 	for kk = 1 : size(tmp1)
% 		tmp2 = ismember(idx0, tmp1(kk));
% 		if any(tmp2)
% 			xy2(kk, :) = g.src.v2d(tmp, :);
% 		else
% 			fprintf('pixel %d is void!\n', kk);
% 			xy2(kk, :) = nan;
% 		end
% 
% 	end
% end
% 		
		

end % end of function

% function [xy, fg] = getMissingValue(nd, tri, idx0)
% 	nn = length(nd);
% 	xy = zeros(nn, 2);
% 	for k = 1 : nn
% 		tmp = any(ismember(tri, nd(k)), 2);
% 		id2 = unique(tri(tmp, :));
% 		[xy2, fg2] = doFind2D(idx0, id2);
% 		fg = ~fg2;
% 		if any(fg)
% 			tmp3 = find(fg, 1);
% 			xy(k, :) = xy2(tmp3, :);
% 		else
% 			[xy3, fg3] = getMissingValue(nd, tri, idx0);
% 		end
% 	end
% end

function [xy, fg] = doFind2D(idx0, ind, l2d)
	n = length(ind);
	xy = zeros(n, 2);
	fg = false(n, 1);
	for k = 1 : n
		tmp = ismember(idx0, ind(k));
		if any(tmp)
			xy(k, :) = l2d(tmp, :);
		else
			xy(k, :) = nan;
			fg(k) = true;
		end
	end
end
