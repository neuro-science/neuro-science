function src = wpa_0GEN_F123Src1TF3ori( tf_data,  aName, sigma, tf_base)
%UNTITLED Summary of this function goes here
% tf_data(ch, trl, tapers)
	tic;
	if nargin < 3
		sigma = 0.01;
	end
	
	%% 	1.1 compute CSD
	[nChs, nTrls, nTprs] = size(tf_data);
	data = permute(tf_data, [3 2 1]); %[taper, trials, chan]
	mp = mean(abs(data), 2);
	C = zeros([nTprs, nChs, nChs]);

	% % % self-pairs		
	for ch = 1 : nChs
		C(:, ch, ch) = squeeze(mp(:, :, ch)).^2;
	end

	% % % inter-pairs
	pCounter = 0; %pair counter
	for ch1 = 1 : nChs - 1	%chan1 / being subtracted
		% % % counter step on	
		pCounter = pCounter + nChs - ch1;
		% % % phase delay between channels
		d = mean(bsxfun(@times, data(:, :, ch1 + 1 : nChs), ...
			conj(data(:, :, ch1))), 2);
		C(:, ch1 + 1 : nChs, ch1) = squeeze(d);
		C(:, ch1, ch1 + 1 : nChs) = d;
		clear d; %free space
	end %end for 1st chans
	clear ch1 mp data pCounter; % free space
	fprintf('C all done after %6.2f minutes.\n', toc/60);

	%% 1.2 source
	v = load(aName);
	nGrids = size(v.a.L, 2); % note:number of grids
	L0 = permute(v.a.L, [1 3 2]);	%[ch, dim, grd]
	clear v;

	% % % do source reconstruction
% 	ori = zeros(3, nGrids);
	A = zeros([3, nChs, nGrids]);
	A1 = zeros([nChs, nGrids]);
	% % % do it in Loop
	% % % prepare data			
	cc = squeeze(nanmean(C, 1)); %[ch, ch], tapers were averaged

	% % % take the real part
	rc = real(cc);
	rc(1 : nChs + 1 : end) = rc(1 : nChs + 1 : end)  + sigma;
	
	% % % compute spf
	parfor iG = 1 : nGrids
		L = L0(:, :, iG);
		tmp = (L' / rc);
		A(:, :, iG) = (tmp * L) \ tmp;
		[v, d] = eig(A(:, :, iG) * rc * A(:, :, iG)');
		tmp = A(:, :, iG)' * v(:, 1);
		if isreal(tmp)
			A1(:, iG) = tmp;
		elseif abs(imag(tmp) ./ real(imag(tmp))) < 0.01
			A1(:, iG) = real(tmp);
		else
			fprintf('======\ncomplex results!\n======\n')
			A1(:, iG) = nan;
		end
	end
	A1 = A1';	%[grid, ch]
	clear d tmp;
	% % % compute data			
	d = reshape(tf_data, [nChs, nTrls*nTprs]);
	src.data = (reshape(A1 * d, [nGrids, nTrls, nTprs]));
	if nargin > 3
		d = reshape(tf_base, [nChs, nTrls*nTprs]);
		src.base = (reshape(A1 * d, [nGrids, nTrls, nTprs]));
	end
% 	src.ori = ori;
	src.A = A;
	src.A1 = A1;
	src.C = C;
	src.L = L0;
	
	% % % clean up
	clear L0 C uu ss vv rc A ori d cc L1;
	
	
	fprintf('Source reconstruction done after %6.1f seconds!\n', toc);
end

