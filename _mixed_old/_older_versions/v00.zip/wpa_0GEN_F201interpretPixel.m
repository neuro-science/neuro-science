% % % interpolate pixels in the image
function y = wpa_0GEN_F201interpretPixel (im, x, method)
% % % input :	im - 3d or 2d image; x - indices of pixels (Nx3 or Nx2)
% % % output: y - values of each pixels
	if nargin < 3
		method = 'cubic';
	end
	sz =  size(im);
	n = size(x, 2);
	if length(sz) == 2 && n == 2
		y = interp2(im, x(:, 2), x(:, 1), method);
	elseif length(sz) == 3 && n == 3
		y = interp3(im, x(:, 2), x(:, 1), x(:, 3), method);
	else
		error('We can deal with only 2-d or 3-d images');
	end
end