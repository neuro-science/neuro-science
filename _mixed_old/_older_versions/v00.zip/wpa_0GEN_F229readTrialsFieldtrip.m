function [sTrials, nTrials] = wpa_0GEN_F229readTrialsFieldtrip (data, con_code)
% % % 9/5/14 read trials from fieldtrip dataformat wp	

	%% select trials
	con_code = [101, 102, 103, 104];
	nCons = length(con_code );
	sTrials = cell(nCons, 1);
	nTrials = zeros(nCons, 1);
	for k = 1 : nCons
		sTrials{k} = find(data.trialinfo(:, 2) == con_code(k));
		nTrials(k) = length(sTrials{k});
	end
	clear data;
