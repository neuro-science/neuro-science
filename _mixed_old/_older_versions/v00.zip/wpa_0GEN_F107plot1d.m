function cfg = wpa_0GEN_F107plot1d(x, y, loc2d, cfg)

	%% 1. set paras
	if nargin < 4
		cfg = [];
	end
	if ~isfield(cfg, 'fsz') || isempty(cfg.fsz)
		cfg.fsz = [100 100 1188 840]; %figure size
	end
	if ~isfield(cfg, 'fc') || isempty(cfg.fc)
		cfg.fc = [1 1 1];	%figure color
	end
	if ~isfield(cfg, 'wd') || isempty(cfg.wd)
		cfg.wd = [1, 0.2, 3]; % linewidth
	end
	if ~isfield(cfg, 'adx') || isempty(cfg.adx)
		cfg.adx = 0.03;	%axes x size relative to figure
	end
	if ~isfield(cfg, 'ady') || isempty(cfg.ady)
		cfg.ady = 0.03;	%axes y size relative to figure
	end
	if ~isfield(cfg, 'xlm') || isempty(cfg.xlm)
		cfg.xlm = [-1500, 4500];	%default x limits in each panel
	end
	if ~isfield(cfg, 'ylm') || isempty(cfg.ylm)
		cfg.ylm = [-200, 200];	%default y limits in each panel
	end
	if ~isfield(cfg, 'xt') || isempty(cfg.xt)
		cfg.xt = -1500 : 1500 : 4500;
	end
	if ~isfield(cfg, 'yt') || isempty(cfg.yt)
		cfg.yt = -400 : 200 : 400;
	end
	if ~isfield(cfg, 'N') || isempty(cfg.N)
		cfg.N = 200;
	end
	if ~isfield(cfg, 'exp') || isempty(cfg.exp)
		cfg.exp = 20; % rate to amplify
	end
	
	%% 2. prepare canvas
	% % % open figure	
	cfg.fid = figure('position', cfg.fsz, 'WindowStyle', 'normal', 'color', cfg.fc); %about A4
	% % % select panels	
	sid = loc2d(:, 1) > 0;
	sa = find(sid);
	na = length(sa);
	cfg.ax = zeros(na, 1);
	
	%% 3. plot
	for k = 1 : na
		if isfield(cfg, 'labels') && ~isempty(cfg.labels)
			cfg.lb = cfg.labels{k};
		end
		pos = [loc2d(sa(k), 4)/2 - cfg.adx/2 + 0.5, loc2d(sa(k), 5)/2 - cfg.ady/2 + 0.5, cfg.adx, cfg.ady];
		cfg.ax(k) = axes('position', pos, 'parent', cfg.fid);
		plot(cfg.ax(k), x, squeeze(y(sa(k), :, :)), 'linewidth', cfg.wd(1));
		set(cfg.ax(k), 'xlim', cfg.xlm, 'xtick', [], ...
			'ylim', cfg.ylm, 'ytick', [], 'ydir', 'reverse',...
			'UserData', cfg, 'buttonDownFcn', {@newFig});
	end

end % end of function


% function fg = myCall(obj, evt, handles)
% 	D1 = 2; D2 = 15;
% 	CurrentPosition = get(obj, 'Position');
% 	OriginalPosition = get(obj, 'UserData');
% 	if CurrentPosition == OriginalPosition
% 		pos = OriginalPosition;
% 		x0 = pos(1) - pos(3) * D1;
% 		y0 = pos(2) - pos(4) * D1;
% 		dx0 = pos(3) * D2;
% 		dy0 = pos(4) * D2;
% 		pos = [x0, y0, dx0, dy0];
% 		set(obj, 'Position', pos, 'layer', 'top');
% 	else
% 		set(obj, 'Position', OriginalPosition);
% 	end
% end %end of subfunction

function f2 = newFig(obj, evt, handles)

	% % % data
	h = get(obj, 'children');
	n = length(h);
	for k = 1 : n
		y(:, k) = get(h(k), 'YData');
	end
	x = get(h(k), 'XData');
	cfg = get(obj, 'UserData');
	
	% % % position	
	pos0 = get(get(obj, 'parent'), 'position');
	pos1 = get(obj, 'position');
	pos(1 : 2) = pos0(1 : 2) + pos0(3 : 4) .* pos1(1 : 2);
	pos(3 : 4) = pos0(3 : 4) .* pos1(3 : 4);
	pos = [pos(1 : 2) + pos(3 : 4) * (0.5 - cfg.exp/2), pos(3 : 4) * cfg.exp];
	f2 = figure('position', pos, 'WindowStyle', 'normal');
	a2 = axes('position', [0.1, 0.1, 0.8, 0.8], 'parent', f2);
	plot(x, y, 'parent', a2, 'linewidth', cfg.wd(3));
	hold on;
	plot(zeros(1, cfg.N), linspace(cfg.ylm(1), cfg.ylm(2), cfg.N), 'r', 'linewidth', cfg.wd(2));
	plot(zeros(1, cfg.N) + 800, linspace(cfg.ylm(1), cfg.ylm(2), cfg.N), 'm', 'linewidth', cfg.wd(2));
	plot(linspace(cfg.xlm(1), cfg.xlm(2), cfg.N), zeros(1, cfg.N), 'r', 'linewidth', cfg.wd(2));
	set(a2, 'xtick', cfg.xt, 'xlim', cfg.xlm, ...
		'ytick', cfg.yt, 'ylim', cfg.ylm, ...
		'ydir', 'reverse');
	if isfield(cfg, 'lb')
		title(a2, cfg.lb);
	end
	
end % end of functions