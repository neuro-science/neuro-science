function [outName, a] = wpa_0GEN_F204readFreeSurferInfo(subDir, subName, srcNums)
%F204 read all relevant information from freesurfer
	%% 1. prepare file names and paths etc.
	a.nSrcs = length(srcNums);
	a.src = cell(nSrcs, 1);
	%% 2. read the src files
	for ic = 1 : a.nSrcs
		fName = [subDir, subName, '/bem/', subName, '-fsaverage-ico-', num2str(ic), '-src.fif'];
		tmp1 = ft_read_headshape(fName, 'format', 'mne_source');
		clear fName;
		if strcmp(tmp1.unit, 'm')
			a.src{ic} = tmp1.pnt * 1000;
		else
			error('wrong format of source space!');
		end
	end
	
	fName = [g.sPath,  a.subName, '/bem/', a.subName, '-fsaverage-ico-5-src.fif'];
	tmp2 = ft_read_headshape(fName, 'format', 'mne_source');
	clear fName;
	tmp3 = mne_read_surfaces('white', 1, 1, 1, a.subName, g.sPath, 1);
	if strcmp(tmp2.unit, 'm')
		a.src2pnt = tmp2.pnt * 1000;
	else
		error('wrong format of source space!');
	end
	a.srf_tri = tmp1.orig.tri;
	a.srf_nrm = [tmp3(1).nn; tmp3(2).nn];
	a.src1tri = tmp1.tri;
	a.src2tri = tmp2.tri;
	a.src1idx = tmp1.orig.inuse;
	a.src2idx = tmp2.orig.inuse;
	clear tmp1 tmp2 tmp fName;
	
	% % % 1.3 project the locations to ctf coordinates	
	a.src1ctf = warp_apply(inv(g.ctf2sfs), a.src1pnt);
	a.src2ctf = warp_apply(inv(g.ctf2sfs), a.src2pnt);
	a.srf_ctf = warp_apply(inv(g.ctf2sfs), a.srf_pnt);
	a.nii2ctf = g.nii2ctf; 
	a.ctf2sfs = g.ctf2sfs;
	a.src1idx = logical(a.src1idx);
	a.src2idx = logical(a.src2idx);
	a.meg2ctf = a.hdr.transformHead2MRI;
	a.ctf2meg = a.hdr.transformMRI2Head;

end

