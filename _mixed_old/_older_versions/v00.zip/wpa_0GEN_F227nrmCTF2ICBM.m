function a = wpa_0GEN_F227nrmCTF2ICBM (mriName, nrmName)
% % % 07/05/2014 Peng Wang	

	
	%% 1. read the ctf mri data 
	a = ft_read_mri(mriName);
	a.vox2ras = [1 0 0 -a.hdr.headOrigin_sagittal; ...
		0 -1 0 a.hdr.headOrigin_coronal; ...
		0 0 -1 a.hdr.headOrigin_axial; ...
		0 0 0 1];

	%% 2. segmentation for brain
	cfg = [];
	cfg.output = {'brain'};
	seg = ft_volumesegment(cfg, a);
	a.brain = seg.brain;
	clear seg;

	%% 3. indices for brain
	idx0 = find(a.brain);   % find the points indices
	[idx(:, 1), idx(:, 2), idx(:, 3)] = ind2sub(a.dim, idx0);	%is brain indices
	xs = min(idx);
	xe = max(idx);
	a.vox2nrm = [1 0 0 -xs(1) + 1;
		0 -1 0 xe(2) + 1;
		0 0 -1 xe(3) + 1;
		0 0 0 1];

	%% 4. new file for normalization
	data = double(a.anatomy) .* double(a.brain);
	t.anatomy = data(xs(1) : xe(1), xe(2): -1 : xs(2), xe(3) : -1 : xs(3));
	t.dim = size(t.anatomy);
	t.transform = a.vox2ras / a.vox2nrm;
	t.id0 = mean(idx);	% 	by center	
	t.transform = [1 0 0 xs(1)-t.id0(1)-1;	%new ras based on geo
		0 1 0 xs(2)-t.id0(2)-1;
		0 0 1 xs(3)-t.id0(3)-1;
		0 0 0 1];

	%% 5. normalise
	cfg = [];
	cfg.template = nrmName;
	cfg.nonlinear = 'no';
	nrm = ft_volumenormalise(cfg, t);
	a.affine = nrm.params.Affine;
	
end % end of function

