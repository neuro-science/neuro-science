function pw = wpa_0GEN_F234getPower(data, trls, dTypeFlag, cTypeFlag)
% % % 09/05/14 written by wp
% % % 12/05/14	updated by wp, use abs for power

	%% check data
	% % % inputs and defaults
	if nargin < 4
		cTypeFlag = 'magnitude';
	end
	
	if nargin < 3
		dTypeFlag = 'cell';
	end
	
	% % % data type
	switch lower(dTypeFlag)
		case {'cell', 'c'}
			[nTs, nFs] = size(data);
			[nUnits, nTrls, tmp] = size(data{1, 1});
			clear tmp;
			str1 = 'c';
		case {'array', 'a'}
			[nUnits, nTrls, nTs, nFs] = size(data);
			str1 = 'a';
		otherwise
			error('Unknown data type!');
	end
	
	% % % compute type
	switch lower(cTypeFlag)
		case {'magnitude', 'm'}
			str2 = 'm';
		case {'power', 'p'}
			str2 = 'p';
		case {'mod', 'd'}
			str2 = 'd';
		otherwise
			error('unkown calculation type!');
	end
	
	% % % trials shall be used
	if nargin < 2
		trls = 1 : nTrls;
	end
	
	% % % str for computation
	str = [str1, str2];
	
	%% compute
	% % % initialize data
	pw = zeros(nUnits, nTs, nFs);
	
	switch str
		case 'cm'
			for it = 1 : nTs
				for iq = 1 : nFs
					pw(:, it, iq) = nanmean(nanmean(abs(data{it, iq}(:, trls, :)), 3), 2);
				end % t-loop
			end % f-loop
		case 'cp'
			for it = 1 : nTs
				for iq = 1 : nFs
					pw(:, it, iq) = nanmean(nanmean((data{it, iq}(:, trls, :) .* ...
						conj(data{it, iq}(:, trls, :))), 3), 2);
				end % t-loop
			end % f-loop
		case 'cd'
			for it = 1 : nTs
				for iq = 1 : nFs
					pw(:, it, iq) = nanmean(nanmean(data{it, iq}(:, trls, :), 3), 2);
				end % t-loop
			end % f-loop
		case 'am'
			data = abs(data);
			pw = permute(nanmean(data(:, trls, :, :), 2), [1 3 4 2]);
		case 'ap'
			data = data .* conj(data);
			pw = permute(nanmean(data(:, trls, :, :), 2), [1 3 4 2]);
		case 'ad'
			pw = permute(nanmean(data(:, trls, :, :), 2), [1 3 4 2]);
		otherwise
			error('unknown string type!');
	end
end % end of this subfuction

