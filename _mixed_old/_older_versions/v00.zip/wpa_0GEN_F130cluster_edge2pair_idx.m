function [idc, idp] = wpa_0GEN_F130cluster_edge2pair_idx (ed, N)
% % % re-written by wp 16/05/14
% % % it is to recover the pair id from node id

	if size(ed, 1) == 2 && size(ed, 2) > 2
		ed = ed';
	end
	
	ct = 0;
	p = zeros(N*(N - 1)/2, 3);
	idc = zeros(size(ed, 1), 1);
	for ch1 = 1 : N - 1
		for ch2 = ch1 + 1 : N
			ct = ct + 1;
			p(ct, 1) = ch1;
			p(ct, 2) = ch2;
			p(ct, 3) = ct;
		end
	end
	
	for k = 1 : size(ed, 1)
		id = p(:, 1) == ed(k, 1) & p(:, 2) == ed(k, 2);
		idc(k) = p(id, 3);
	end

	idp = unique(ed(:));
end
