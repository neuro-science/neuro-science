function H1 = wpa_0GEN_F131threshFindInCluster (H0, pth)
% % % written by wp 22/05/14
% % % 
	sz = size(H0);
	if length(sz) > 2
		error('too complex, only 2d accepted!');
	elseif sz(1) < sz(2)
		H0 = H0';
		fprintf('converted, 1d is tests!\n');
		sz = sz([2, 1]);
	end
	
	if pth > 0.1 || pth < 0
		warning('this pvalue is strange!');
	end
	
	rk = round((1 - pth) * sz(1));
	[Y, I] = sort(H0(:, 1));
	th1 = Y(rk);
	H2 = H0(:, 2:end);
	H_all = sort([Y; H2(H2 > th1)]);
	rk = round((1 - pth) * length(H_all));
	H1 = H_all(rk);
	
end
