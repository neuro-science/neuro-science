function t = wpa_0GEN_F236ctrlPower(data, trls, dTypeFlag, cTypeFlag, cT)
% % % 12/05/14	written by wp
% % %		if input trls size is Nx2, then compute contrast 2 vs. 1
% % %		else compute contrast with cT (default T1)

	%% check data
	% % % inputs and defaults
	if nargin < 5
		cT = 1;
	end
	
	if nargin < 4
		cTypeFlag = 'magnitude';
	end
	
	if nargin < 3
		dTypeFlag = 'cell';
	end
	
	% % % data type
	switch lower(dTypeFlag)
		case {'cell', 'c'}
			[nTs, nFs] = size(data);
			[nUnits, nTrls, tmp] = size(data{1, 1});
			clear tmp;
			str1 = 'c';
		case {'array', 'a'}
			[nUnits, nTrls, nTs, nFs] = size(data);
			str1 = 'a';
		otherwise
			error('Unknown data type!');
	end
	
	% % % compute type
	switch lower(cTypeFlag)
		case {'magnitude', 'm'}
			str2 = 'm';
		case {'power', 'p'}
			str2 = 'p';
		case {'mod', 'd'}
			str2 = 'd';
		otherwise
			error('unkown calculation type!');
	end
	
	% % % trials shall be used
	if nargin < 2 || isempty(trls)
		trls = [1 : nTrls]';
	end
	sz = size(trls);
	
	% % % str for computation
	str = [str1, str2];
	
	%% compute
	% % % transform data
	switch str
		case 'cm'
			pw = zeros(nUnits, nTrls, nTs, nFs);
			for it = 1 : nTs
				for iq = 1 : nFs
					pw(:, :, it, iq) = nanmean(abs(data{it, iq}), 3);
				end % t-loop
			end % f-loop
			clear data;
		case 'cp'
			pw = zeros(nUnits, nTrls, nTs, nFs);
			for it = 1 : nTs
				for iq = 1 : nFs
					pw(:, it, iq) = nanmean((data{it, iq} .* conj(data{it, iq})), 3);
				end % t-loop
			end % f-loop
			clear data;
		case 'cd'
			pw = zeros(nUnits, nTrls, nTs, nFs);
			for it = 1 : nTs
				for iq = 1 : nFs
					pw(:, it, iq) = nanmean(data{it, iq}, 3);
				end % t-loop
			end % f-loop
			clear data;
		case 'am'
			pw = abs(data);
			clear data;
		case 'ap'
			pw = data .* conj(data);
			clear data;
		case 'ad'
			pw = data;
			clear data;
		otherwise
			error('unknown string type!');
	end
	
	% % % generate difference in data
	if sz(2) == 1
		d = bsxfun(@minus, pw(:, trls, :, :), pw(:, trls, cT, :));
	elseif sz(2) == 2
		d = pw(:, trls(:, 2), :, :) - pw(:, trls(:, 1), :, :);
	else
		error('unexpected trial groups, dimension other than 1 or 2!');
	end
	
	% % % compute t value
	t = wpa_0GEN_F235computeT(d, 2);
	
end % end of this subfuction

