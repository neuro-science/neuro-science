function  out = wpa_0GEN_F211z4coh (in, nTrls, nTapers, fd, rd)
%re-written 18/05/14 by wp
% % % for more flexible data

% % %   Detailed explanation goes here
% % %		expect input as :
% % %		in (pair, time, freq)
% % %		nTrls scalar
% % %		nTapers (nFs x 1) or 1

	%% 1. check headers
	sz = size(in);
	if nargin < 3
		nTapers = 1;
	elseif nargin < 4
		fd = length(sz);
	elseif nargin < 5
		rd = length(sz);
	end
	nFs = sz(fd);
	
	% % % coherence value > 1, could be cauculating inacurately 
	% % % because of limitation of single/double precisions.
	idx = find(in > 1);
	if ~isempty(idx)
		r1 = 100 * length(idx) / numel(in);
		r2 = (max(in(idx)) - 1) * 100;
		if r2 < 1
			in(idx) = 1;
			fprintf('!!! %5.1f%% of values are larger than 1, maximum %5.1f%%. !!!\n', r1, r2);
		else
			error('Incredibly coherence values, >1 by %6.1f%%.', r2);
		end
	end
	
	id0 = find(in < -1, 1);
	if ~isempty(id0)
		error('Incredibly coherence values, < -1 !');
	end
	
	%% 2. check whether tapers are not scalar
	if numel(nTapers) > 1
		nFts = length(nTapers);
		if nFts ~= nFs
			error('wrong size of frequencies!');
		else
			sz0 = ones(size(sz));
			sz0(fd) = sz(fd);
			sz1 = sz;
			sz1(fd) = 1;
			v = reshape(nTapers, sz0);
			vf = repmat(v, sz1);
			clear v sz0 sz1;
		end
	else
		vf = nTapers;
	end
	if numel(nTrls) > 1
		sz0 = ones(size(sz));
		sz0(rd) = sz(rd);
		sz1 = sz;
		sz1(rd) = 1;
		v = reshape(nTrls, sz0);
		vr = repmat(v, sz1);
		clear v sz0 sz1;
	else
		vr = nTrls;
	end
	v = vf .* vr;
	
	%% 3. calculation
	out = 23 / 20 * (sqrt(log(1 - in .^ 2) .* (2 - v)) - 23 / 20);
	clear in v;
end

