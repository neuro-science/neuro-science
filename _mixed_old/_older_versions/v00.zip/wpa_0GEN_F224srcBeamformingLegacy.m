function [CC, data, ori, AAA] = wpa_0GEN_F224srcBeamformingLegacy (tf_data, LL)
	
	%% CSD computation
	% % % and check size		
	[nTs, nFs] = size(tf_data); 
	nChs = size(tf_data{1, 1}, 1);
	% % % initialize		
	CC = cell(nTs, nFs);	%CSD for each time and frequency separately

	% % % compute for each frequency and time		
	for f = 1 : nFs
		for t = 1 : nTs
			% % % initialize
			data = permute(tf_data{t, f}, [3 2 1]); %[chan, trials, taper] -> [taper, trials, chan]
			nTprs = size(data, 1);
			mp = mean(abs(data), 2);
			CC{t, f} = zeros([nTprs, nChs, nChs], 'single');

			% % % self-pairs		
			for ch = 1 : nChs
				CC{t, f}(:, ch, ch) = squeeze(mp(:, :, ch)).^2;
			end

			% % % inter-pairs
			pCounter = 0; %pair counter
			for ch1 = 1 : nChs - 1	%chan1 / being subtracted
				% % % counter step on	
				pCounter = pCounter + nChs - ch1;
				% % % phase delay between channels
				d = mean(bsxfun(@times, data(:, :, ch1 + 1 : nChs), ...
					conj(data(:, :, ch1))), 2);
				CC{t, f}(:, ch1 + 1 : nChs, ch1) = squeeze(d);
				CC{t, f}(:, ch1, ch1 + 1 : nChs) = d;
				clear d; %free space
			end %end for 1st chans
			clear ch1 mp data nTprs pCounter; % free space
		end
		fprintf('Done for frequency No.%d after %6.1f seconds. \n', f, toc(t1));
	end
	
	%% beamforming
	nGrids = size(LL, 2); % note:number of grids
	L0 = permute(LL, [1 3 2]);	%[ch, dim, grd]
		
	% % % do it in Loop
	for iF = 1 : nFs
		for iT = 1 : nTs
			% % % prepare data			
			[nChs, nTrls, nTprs] = size(tf_data{iT, iF});
			d = reshape(tf_data{iT, iF}, [nChs, nTrls*nTprs]);
			cc = squeeze(mean(CC{iT, iF}, 1)); %[ch, ch], tapers were averaged

			% % % compute gim
			rc = real(cc);

			% % % compute spf
			A = zeros(g.nGrids, nChs);
			ori1 = zeros(3, g.nGrids);
			parfor iG = 1 : g.nGrids
				L = L0(:, :, iG);
				[uu, ss, vv] = svd(real(pinv(L' / rc * L)));
				L1  = L * uu(:,1);
				ori1(:, iG) = uu(:,1);
				tmp = (L1' / rc);	%spatial filter 1/2
				A(iG, :) = (tmp * L1) \ tmp; %spatial filter 2/2
			end

			% % % compute data			
			ori(:, :, iT, iF) = ori1;
			AAA(:, :, iT, iF) = A;
			data{iT, iF} = single(reshape(A * d, [nGrids, nTrls, nTprs]));
 
			% % % clean up
			clear uu ss vv rc ci tmp d cc pw2 sTrials;
		end % end of t
	end %end of f	
	
end %end of function