function [tf_data, myWinSizes, nTapers, myWins, myTapers, myIndFFT] = ...
	wpa_0GEN_F100MultitaperFFT(data, sRate, timeStart, xTimes, yFreqs, winSizes, resFreq, fid)
% % % 12/06/14 updated by wp: direct output to fid if available

% % % tf_data = wpa_0Gen_F100MultitaperFFT(data, sRate, timeStart, xTimes, yFreqs, winSizes, resFreq)
% % % The data shall be in channel x point x trial format
% % % The unit of timeStart, xTimes and winSize is ms and the unit of yFreq is Hz
% % % frequency resolution shall be one number indicating octaves(log2(fMax/fMin))
% % % winSize shall be one number in ms, later may be extended
% % % output is a cell array tf_data{time, freq}, the element is [channel, trial, taper]

	%% preparison
	tic;
	if nargin < 8 || isempty(fid)
		fid = 1;
	end
	
	% % % data info
	[nChans, nPoints, nTrials] = size(data);
	nTimes = length(xTimes);
	nFreqs = length(yFreqs);
	tf_data = cell(nTimes, nFreqs);
	% % % reshape data to [points, trial*channel]
	data = reshape(permute(data, [2 3 1]), [nPoints, nTrials * nChans]);
	% % % calculate time indices
	xPoints = round((xTimes - timeStart) * sRate /1000) + 1;
	if min(xPoints) < 1
		error('Time range was exceeded in the left!');
	end
	if max(xPoints) > nPoints
		error('Time range was exceeded in the right!');
	end
	% % % the window sizes will change slightly to meet integer number of tapers
	myWinSizes = zeros(nFreqs, 1) + winSizes / 1000 * sRate;
	myWins = zeros(nFreqs, 2);
	nTapers = zeros(nFreqs, 1);
	myTapers = cell(nFreqs, 1);
	myIndFFT = zeros(nFreqs, 1);
	%% taper calculation
	for f = 1 : nFreqs
		df = yFreqs(f) * (2.^(resFreq/2) - 2.^(-resFreq/2));
		if yFreqs(f) >= 15.9 % 16+
% 		theFreq = yFreqs(f);
			nTapers(f) = round(df * winSizes /1000) - 1;
		else
			nTapers(f) = 1;
		end
		myWinSizes(f) = round((nTapers(f) + 1) / df * sRate);
		myWins(1, f) = -floor(myWinSizes(f)/2);
		myWins(2, f) = myWins(1, f) + myWinSizes(f) - 1;
		tmpFreq = linspace(0, sRate/2, ceil(myWinSizes(f)/2));
		[tmp, myIndFFT(f)] = min(abs(tmpFreq - yFreqs(f)));
		[e, v] = dpss(myWinSizes(f), myWinSizes(f) * df / sRate / 2);
		myTapers{f} = permute(e(:, 1 : nTapers(f)), [1 3 2]);	%facilate bsxfun
		clear tmp tmpFreq df e v;
	end

	%% calculation
	for f = 1 : nFreqs
		for t = 1 : nTimes
			% % % select data
			sid = xPoints(t) + (myWins(1, f) : myWins(2, f));	%indices needed
			padFlag = 0;	%initialize
			n1 = 0;
			n2 = 0;
			id1 = find(sid < 1);	%left exceed
			if ~isempty(id1)
				n1 = length(id1);
				fprintf(fid, 'Indices exceeded left side in [%d ms,%6.2f Hz], padding %d zeros...\n', ...
					xTimes(t), yFreqs(f), n1);
				sid(id1) = 1;	%use first points
				padFlag = 1;
			end
			id2 = find(sid > nPoints);	%right exceed
			if ~isempty(id2)
				n2 = length(id2);
				fprintf(fid, 'Indices exceeded right side in [%d ms,%6.2f Hz], padding %d zeros...\n', ...
					xTimes(t), yFreqs(f), n2);
				sid(id2) = nPoints;	%use last points
				padFlag = 1;
			end
			theData = data(sid, :);	%get data
			if padFlag
				theData([1 : n1, end - n2 + 1 : end], :) = 0; %pad zeros
			end
			% % % apply taper [points, trial*channel, taper]
			theData = bsxfun(@times, theData, myTapers{f});
			% % % do FFT			
			theTF = fft(theData);
			% % % sort data to [channel, trial, taper]			
			tf_data{t, f} = permute(reshape(theTF(myIndFFT(f), :, :), ...
				[nTrials, nChans, nTapers(f)]), [2 1 3]);
% 			clear theTF theData padFlag sid id1 id2 n1 n2;
		end
		fprintf(fid, 'Done for frequency %6.2f after %6.1f seconds. \n', yFreqs(f), toc);
	end
end %end of function