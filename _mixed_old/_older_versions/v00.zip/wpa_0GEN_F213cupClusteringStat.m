function cfg = wpa_0GEN_F213cupClusteringStat (cfg)

	%% 1. check headers
	t1 = tic;
	% % % load data	
	if isfield(cfg, 'in')
		v = load(cfg.in);
	else
		error('no data file defined!');
	end
	
	% % % check size
	szFlag = size(v.cz) - [cfg.nPairGrids, cfg.nTimes, cfg.nFreqs, cfg.nSubjects];
	if all(~szFlag) %between conditions
		fprintf('Comprison between conditions!\n');
	elseif all(~szFlag([1 3 4])) && szFlag(2) == -1;
		cfg.tid = cfg.tid - 1;
		fprintf('Comprison between stimulus and baseline, time point shift 1 to the left!\n');
	else
		error('data size is not expected!');
	end
	cz = v.cz(:, cfg.tid, cfg.qid, :);
	clear v;
	cfg.xTimes = cfg.xTimes(cfg.tid);
	cfg.yFreqs = cfg.yFreqs(cfg.qid);
	cfg.nTimes = length(cfg.tid);
	cfg.nFreqs = length(cfg.qid);
	
	% % % allocate space
	cfg.cc = cell(cfg.nClustersPerTest, cfg.nMethods, cfg.nSigns);
	cfg.sz = zeros(cfg.nClustersPerTest, cfg.nMethods, cfg.nSigns);
	
	%% 2. do clustering
	% % % format data
	m = mean(cz, 4); %[pr, t, f]
	sd = std(cz, 0, 4);
	con = permute(sqrt(cfg.nSubjects) * m ./ sd, [3, 2, 1]);	%t value [f, t, pr]
	clear m sd;
	fprintf('Header time cost is %6.1f seconds for file %s!\nNow clustering ...\n', toc(t1), cfg.tag);
		
	for k = 1 : cfg.nSigns	% loop for signs
		% % % check the sign
		switch lower(cfg.sign{k}(1))
			case 'p'	%positive
				cn = con;
			case 'n'	%negative
				cn = -con;
			case 'b'	%both
				cn = abs(con);
			case 'a'	%absolute
				cn = abs(con);
			otherwise
				error('wrong in sign switch!');
		end
		
		% % % do computation
		for im = 1 : cfg.nMethods % loop for clustering methods
			% % % prepare para for par 		
			tic;
			[cc, sz, nc] = wpa_0GEN_F17cohClustering (cn, cfg.tp, cfg.th1, cfg.th2, cfg.method{im});
			tmpL = size(sz, 1);
			if tmpL >= cfg.nClustersPerTest
				cfg.cc(:, im, k) = cc(1 : cfg.nClustersPerTest);
				cfg.sz(:, im, k) = sz(1 : cfg.nClustersPerTest);
			elseif tmpL > 0
				cfg.cluster(1 : tmpL, im, k) = cc;
				cfg.sz(1 : tmpL, im, k) = sz;
			else
				fprintf(' \n!!!No clusters found for sign %s of method %s in data %s!!! \n\n', ...
					cfg.sign{k}, cfg.method{im}, cfg.tag);
			end
			fprintf('Time cost is %6.1f seconds for sign %s of method %s in data %s!!! \n\n', ...
				toc, cfg.sign{k}, cfg.method{im}, cfg.tag);
		end
		clear cn;
	end
	clear con;
	
	%% 3. statistics
	if cfg.stat
		% % % prepare
		fprintf('Statistics demanded, it may take long time...\n');
		cfg.H0 = zeros(cfg.nNumPerRepeat, cfg.nRepeatPerCluster, cfg.nMethods);
		s0 = randperm(2 .^ cfg.nSubjects);
		s1 = ismember(dec2bin(s0(1 : cfg.nRepeatPerCluster), cfg.nSubjects), '1');
		clear s0;
		
		% % % do in loop for repeats
		for ir = 1 : cfg.nRepeatPerCluster
			% % % data in
			tic;
			czr = bsxfun(@times, cz, 2 * (permute(s1(ir, :), [1 3 4 2]) - 0.5));
			m = mean(czr, 4);
			sd = std(czr, 0, 4);
			con = permute(sqrt(cfg.nSubjects) * m ./ sd, [3, 2, 1]);	%[f, t, pr]
			clear m sd;
			
			% % % do it for each method in loop
			for im = 1 : cfg.method
				[tmp1, sz, tmp3] = wpa_0GEN_F17cohClustering (con, cfg.tp, cfg.th1, cfg.th2, cfg.method{im});
				ssz = length(sz);
				if ssz >= cfg.nNumPerRepeat
					cfg.H0(:, ir, im) = sz(1 : cfg.nNumPerRepeat);
				elseif ssz > 0
					cfg.H0(1 : ssz, ir, im) = sz;
				else
					fprintf('No cluster here!\n')
				end
			end
			fprintf('Test #%03d after %7.2f seconds in %s.\n', ir, toc, cfg.tag);
		end
	else
		fprintf('No statistics demanded, skipping...\n');
	end
	
	%% 4. save the data
	save(cfg.out, 'cfg');
	fprintf('All done!\nTime cost is %6.1f minutes for data %s!!! \n\n', toc/60, cfg.tag);
	
end %end of function