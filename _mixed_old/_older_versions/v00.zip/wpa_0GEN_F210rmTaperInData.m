function out = wpa_0GEN_F210rmTaperInData (in)
% % %		in : tf in {time, freq}(chan, trial, taper)
% % %		out : tf in {chan, trial, time, freq)
	[nTs, nFs] = size(in);
	[nChs, nTrls, tmp] = size(in{1, 1});
	out = zeros(nChs, nTrls, nTs, nFs, 'single');
	for iq = 1 : nFs
		for it = 1 : nTs
			out(:, :, it, iq) = single(nanmean(in{it, iq}, 3));
		end
	end
	
end