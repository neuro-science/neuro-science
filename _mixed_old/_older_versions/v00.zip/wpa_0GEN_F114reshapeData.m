function y = wpa_0GEN_F114reshapeData(x, N)
	% % % 03/06/14 by wp
	% % % reshape data from 2d to 3d
	[m, n] = size(x);
	S = N - mod(n, N);
	s = floor(S / 2);
	z1 = zeros(m, s);
	z2 = zeros(m, S - s);
	y = reshape([z1, x, z2], [m, N, floor(n / N) + 1]);
end