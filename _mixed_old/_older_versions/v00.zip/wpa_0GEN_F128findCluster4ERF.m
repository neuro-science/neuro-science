function [c, nc] = wpa_0GEN_F128findCluster4ERF (binArray, nb)

	sz = size(binArray);
	[x1, x2] = ind2sub(sz, find(binArray));
	nds = length(x1);
	flg = true(nds, 1);
	ids = [x1, x2];
	nc = 0;
	c = [];
	for ig = 1 : nds
		if flg(ig)
			cid = [];
			[cid, flg] = searchClusterLoopSparse(ids, ig, cid, flg, nb);
			if ~isempty(cid)
				nc = nc + 1;
				c{nc}.ne = length(cid);
				c{nc}.ed = ids(cid, :);
				c{nc}.nd = unique(ids(cid, 1));
				c{nc}.nn = length(c{nc}.nd);
				c{nc}.id = sub2ind(sz, x1(cid), x2(cid));
			end
		end
	end
end

function [y, flg] = searchClusterLoopSparse(ids, x, y, flg, nb)
	ng = length(x);
	x2 = [];
	for k = 1 : ng
		if flg(x(k))
			flg(x(k)) = 0;
			y = [y; x(k)];
			s1 = ids(:, 1) == ids(x(k), 1);
			s2 = abs(ids(:, 2) - ids(x(k), 2)) == 1;
			s3 = ids(:, 2) == ids(x(k), 2);
			s4 = ismember(ids(:, 1), nb{ids(x(k), 1)});
			s = find((s1 & s2) | ((~s1) & s3 & s4));
			x2 = [x2; s];
		end
	end
	x2 = unique(x2);
	if ~isempty(x2)
		[y, flg] = searchClusterLoopSparse(ids, x2, y, flg, nb);
	end
end
