% % % This function is to sort the events and thus trials can be epoched
% % % without behavioral data (later need to be corrected for RT etc.)

function myEvt = wpa_0GEN_F115SortMEGEvents(meg_evt, longRespSecs, freqSampling)

% % % modified on 7/9/2013
	if nargin < 2
		longRespSecs = 10;
	end
	if nargin < 3
		freqSampling = 1200;
	end
	evt = struct2cell(meg_evt);	% get original data events
	%% get all events
	nTriggers = 0;		%initial number of triggers and responses
	nResponses = 0;
	for iEvt = 1 : size(evt, 2)
		switch evt{1, iEvt}		% sort events
			case 'UPPT001'		%trigger of stimulus
				nTriggers = nTriggers + 1;
				trgType(nTriggers) = evt{3, iEvt};
				trgPointsOrigin(nTriggers) = evt{2, iEvt};
			case 'UPPT002'		%response
				nResponses = nResponses + 1;
				rspType(nResponses) = evt{3, iEvt};
				rspPointsOrigin(nResponses) = evt{2, iEvt};
			otherwise;
		end
	end
	rspTypeKey = log2(rspType - 224);	%key to key id

	%% sort all events
	myEvt.nEvents = nTriggers;	%initial event data
	myEvt.StiType = zeros(myEvt.nEvents, 1) + nan;
	myEvt.TrigSample = zeros(myEvt.nEvents, 1) + nan;
	myEvt.RspTime = zeros(myEvt.nEvents, 1) + nan;
	myEvt.RspType = zeros(myEvt.nEvents, 1) + nan;
	myEvt.RspTimePools = cell(nTriggers, 1);	%size  nTriggers
	myEvt.RspTypePools = cell(nTriggers, 1);	%size  nTriggers
	for iTrg = 1 : myEvt.nEvents
		if iTrg < nTriggers
			t0 = trgPointsOrigin(iTrg + 1);
		else
			t0 = trgPointsOrigin(iTrg) + freqSampling * longRespSecs;
		end
		myEvt.StiType(iTrg) = trgType(iTrg);	%set value
		myEvt.TrigSample(iTrg) = trgPointsOrigin(iTrg);	%set value
		idx = (rspPointsOrigin > trgPointsOrigin(iTrg)) & (rspPointsOrigin < t0);
		myEvt.RspTimePools{iTrg} = (rspPointsOrigin(idx) - myEvt.TrigSample(iTrg)) ./ freqSampling;
		myEvt.RspTypePools{iTrg} = rspTypeKey(idx);
	end
	
	
end %end of function