function [cMap, sid] = wpa_0GEN_F232Value2MyColor(d, th, M, style)
% % % modified 19/5/14 wp:
% % %		- >= th instead of >
% % % modified 12/5/14 wp:
% % %		- sid will always compute
% % %		- relative threshold
% % %		- colormap selection

% % % modified 9/5/14 wp
% % %		- color: (dark) blue - cyan - green - yellow - red (dark)

	%% 1. check input
	% % % v shall be a vector
	sz = size(d);
	if length(sz) > 2
		error('Data input shall be Nx1 vectors!');
	elseif sz(2) == 1
		v = d;
	elseif sz(1) == 1
		v = d';
		fprintf('Switch from row to column vectors!\n');
	else
		error('Data input shall be Nx1 vectors!');
	end
	
	if nargin < 4 || isempty(style)
		style = 'jet';
	end
	
	if nargin < 3 || isempty(M)
		M = max(abs(v));
	end
	
	if nargin < 2 || isempty(th)
		th = 0.2;
	end
	
	%% 2. normalize to [-1 1]
	v = v/M;
	v(v > 1) = 1;
	v(v < -1) = -1;
	
	%% 3. check output
	sid = abs(v) >= th;
	cMap = zeros(size(v, 1), 3);
	
	%% 4. fill colors
	switch lower(style)
		case {'jet', 'j'}
			idx = v >= 0.75;
				cMap(idx, 1) = 1 - (v(idx) - 0.75) * 2; 
				cMap(idx, 2:3) = 0; 

			idx = v < 0.75 & v >= 0.25;
				cMap(idx, 1) = 1; 
				cMap(idx, 2) = 1 - (v(idx) - 0.25) * 2; 
				cMap(idx, 3) = 0; 

			idx = v < 0.25 & v > -0.25;
				cMap(idx, 1) = (v(idx) + 0.25) * 2; 
				cMap(idx, 2) = 1; 
				cMap(idx, 3) = 1 - (v(idx) + 0.25) * 2; 

			idx = v <= -0.25 & v > -0.75;
				cMap(idx, 1) = 0; 
				cMap(idx, 2) = 1 + (v(idx) + 0.25) * 2; 
				cMap(idx, 3) = 1; 

			idx = v <= -0.75;
				cMap(idx, 1) = 0; 
				cMap(idx, 2) = 0; 
				cMap(idx, 3) = 1 + (v(idx) + 0.75) * 2; 
		case {'hot', 'h'}
			tmp = find(v < 0, 1);
			if ~isempty(tmp)
				fprintf('Warning: you are using hot scale but the values contain negative!\n');
			end
			
			idx = v < 0;
			sid(idx) = 0;
			
			idx = v <= 3/8;
			cMap(idx, 1) = v(idx) * 8/3;
			cMap(idx, 2) = 0;
			cMap(idx, 3) = 0;
			
			idx = v <= 3/4 & v > 3/8;
			cMap(idx, 1) = 1;
			cMap(idx, 2) = (v(idx) - 3/8) * 8/3;
			cMap(idx, 3) = 0;
			
			idx = v > 3/4;
			cMap(idx, 1) = 1;
			cMap(idx, 2) = 1;
			cMap(idx, 3) = (v(idx) - 3/4) * 4;
		otherwise
			error('unkown color map!');
	end
		
	clear idx;
	cMap(~sid, :) = nan;

	
end %end of function

