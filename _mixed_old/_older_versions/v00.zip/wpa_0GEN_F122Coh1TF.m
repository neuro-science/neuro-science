function coh = wpa_0GEN_F122Coh1TF( data, sTrials )
%UNTITLED2 Summary of this function goes here
%   data(ch, trl, taper)
	if nargin < 2
		sTrials = 1 : size(data, 2);	%all trials
	end
	nGrids = size(data, 1);
	nPairs = nGrids * (nGrids - 1) / 2;
	coh = zeros(nPairs, 3);	
	pCounter = 0; %pair counter
	pw2 = mean(data .* conj(data), 3);	%power [grd, tr]
	for ch1 = 1 : nGrids - 1	%chan1 / being subtracted
		% % % index of pairs				
		pID = pCounter + 1 : pCounter + nGrids - ch1;
		% % % counter step on for channel	
		pCounter = pCounter + nGrids - ch1;
		% % % common data
		tCoh = mean(bsxfun(@times, data(ch1 + 1 : nGrids, :, :), conj(data(ch1, :, :))), 3); %[grd, trl]
		pwx = bsxfun(@times, pw2(ch1 + 1 : nGrids, :), pw2(ch1, :)); %[grd, trl]
		dCoh = tCoh ./ sqrt(pwx); %[grd, trl, tp]
		clear pwx;
		pw1 = sqrt(bsxfun(@times, sum(pw2(ch1 + 1 : nGrids, sTrials), 2), sum(pw2(ch1, sTrials), 2)));
		
		% % % specified for trial groups
		coh(pID, 1) = abs(sum(tCoh(:, sTrials), 2)) ./ pw1;
		coh(pID, 2) = abs(mean(dCoh(:, sTrials), 2));
		coh(pID, 3) = sum(imag(tCoh(:, sTrials)), 2) ./ pw1;
		clear tCoh dCoh tCoh0 dCoh0;
	end
end %end of function

