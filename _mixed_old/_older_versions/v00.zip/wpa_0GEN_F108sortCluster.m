function r = wpa_0GEN_F108sortCluster(ed, description)
% % % 19/05/14 written by wp

	%% check inputs
	if nargin < 2
		error(['You need to input two varibles: data(cases x types) ', ...
		'and type names ("c (channel)", "t(time)", "f(frequency)")!']);
	end
	
	td = find(ismember(description, 't'));
	if numel(td) > 1
		error('only 1 time dimension allowed!');
	elseif isempty(td)
		fprintf('no time input!\n');
		tFlag = 0;
	else
		tx = ed(:, td);
		tFlag = 1;
	end
	
	fd = find(ismember(description, 'f'));
	if numel(fd) > 1
		error('only 1 time dimension allowed!');
	elseif isempty(fd)
		fprintf('no freq input!\n');
		fFlag = 0;
	else
		fx = ed(:, fd);
		fFlag = 1;
	end
	
	nd = find(ismember(description, 'c'));
	if numel(nd) > 2
		error('max 2 channel dimension allowed!');
	elseif isempty(nd)
		fprintf('no channel input!\n');
		nFlag = 0;
	else
		nx = ed(:, nd);
		nx = nx(:);
		nFlag = 1;
	end
	
	%% do counting
	if nFlag
		r.nid = 1 : max(nx);
		r.ny = histc(nx, r.nid);
	end
	
	if tFlag && fFlag
		r.tid = min(tx) : max(tx);
		r.fid = min(fx) : max(fx);
		nts = length(r.tid);
		nfs = length(r.fid);
		r.tfy2 = zeros(nfs, nts);
		for it = 1 : nts
			for iq = 1 : nfs
				r.tfy2(iq, it) = length(find(fx == r.fid(iq) & tx == r.tid(it)));
			end
		end
		r.ty = sum(r.tfy2, 1)';
		r.fy = sum(r.tfy2, 2);
	elseif tFlag
		r.tid = min(tx) : max(tx);
		r.ty = histc(tx, r.tid);
	elseif fFlag
		r.fid = min(fx) : max(fx);
		r.fy = histc(fx, r.fid);
	end

end % end of function