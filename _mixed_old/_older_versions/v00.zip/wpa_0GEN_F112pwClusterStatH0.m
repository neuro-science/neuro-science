function H0 = wpa_0GEN_F112pwClusterStatH0(data, tp, th1, th2, nClustersPerTest, nTestPerCluster, nSubs)
	
	%data[f, t, ch, sb]
	
	%% initialize
	H0 = zeros(nClustersPerTest, nTestPerCluster);
	s0 = randperm(2.^nSubs);
	s1 = ismember(dec2bin(s0(1 : nTestPerCluster), nSubs), '1');
	clear s0;
	
	%% do in loop
	parfor ts = 1 : nTestPerCluster
		tic;

		% % % prepare data		
		cz = bsxfun(@times, data, 2 * (permute(s1(ts, :), [1 3 4 2]) - 0.5));
		con = wpa_0GEN_F235computeT(cz, 4);

		% % % do cluster
		[tmp1, sz, tmp3] = wpa_0GEN_F109pwClustering (con, tp, th1, th2);
		
		% % % fill the results		
		szn = zeros(nClustersPerTest, 1);
		ssz = length(sz);
		if ssz >= nClustersPerTest
			szn(:, 1) = sz(1 : nClustersPerTest);
		elseif ssz > 0
			szn(1 : ssz, 1) = sz;
		end
		H0(:, ts) = szn;
		
		% % % echo message		
		fprintf('Test #%03d done after %7.2f seconds.\n', ts, toc);
	end
	
end %end of function

