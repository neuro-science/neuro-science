function p = wpa_0GEN_F106src4erf_trace(d, A)
% % % 02/06/14 modified a little by wp for parallel computation
% % % original code by guido as [F1,p,dipori] = getdipdir(cs, A), listed
% % % below to show respect

	% % % d - Nx1				power at certain time point/condition etc. N = nchans
	% % % A - N x M x 3		spatial filter M = nvxs

	%% prepare data
	C = d * d';	%covariance NxN
	[nchs, nvxs, ndms] = size(A); %get size
	if ndms ~= 3
		error('spatial filter shall be nChs x nVXs x 3 in size!');
	else
		A = permute(A, [1, 3, 2]);	%Nx3xM
	end
	p = zeros(nvxs, 1); %Mx1 src

	%% do computation
	for k = 1 : nvxs;
		p(k) = trace(A(:, :, k)' * C * A(:, :, k));
	end

end
    
%% original code by Guido Nolte
% % % function [F1,p,dipori]=getdipdir(cs,A);
% % % 
% % % cs=real(cs);
% % % [nchan ng ndum]=size(A);
% % % p=zeros(ng,1);
% % % F1=zeros(nchan,ng);
% % % dipori=zeros(ndum,ng);
% % % for i=1:ng;
% % %     Aloc=squeeze(A(:,i,:));
% % %     csloc=Aloc'*cs*Aloc;
% % %     [u s v]=svd(csloc);
% % %     F1(:,i)=Aloc*u(:,1);
% % %     p(i)=s(1,1);
% % %     dipori(:,i)=u(:,1);
% % % end
% % % 
% % % return;
% % %     